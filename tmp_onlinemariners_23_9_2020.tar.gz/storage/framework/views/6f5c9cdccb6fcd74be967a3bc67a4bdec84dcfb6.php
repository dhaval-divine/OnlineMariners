<?php $__env->startSection('content'); ?>
    <section class="inner-header-title" style="background-image:url(public/assets/img/bn2.jpg);">
        <div class="container">
            <h1>Create And Account</h1>
        </div>
    </section>
    <div class="clearfix"></div>
    <section class="tab-sec gray">
        <div class="container">
            <div class="col-lg-8 col-md-8 col-sm-12 col-lg-offset-2 col-md-offset-2">
                <div class="new-logwrap">
                <!-- Flash Msg on success-->
                <?php if( session('success') ): ?>
                    <div class="alert alert-success alert-dismissable fade in">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <b>Success ! </b><?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <div class='row'>
                    <table style="width:100%" class='col-sm-12'>
                    <tr>
                        <th style="width:70%; text-align:center;" >User Email verification status: </th>
                        <th style="width:30%"><span style='color:red;'>Not Verified</span>
                        <!-- <img src="<?php echo e(asset('assets/img/not-varified.png')); ?>" width='20' height='20' alt='verification-img-status'/> -->
                        </th> 
                    </tr>
                    </table>
                </div>
                
                <!-- End Flash Msg on success-->
                <!-- <ul class="nav modern-tabs nav-tabs theme-bg" id="simple-design-tab">
                    <li class="active"><a href="#candidate">Candidate</a></li>
                    <li><a href="#employer">Employer</a></li>
                </ul>
                
                <div class="tab-content">
                    <div id="candidate" class="tab-pane fade in active">
                        <form method="POST" action="<?php echo e(route('signup.create')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type='hidden' name='user-type' value='candidate'>
                            <div class="form-group">
                                <label>Username</label>
                                <div class="input-with-icon">
                                    <input type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" 
                                    value="<?php echo e(old('name')); ?>" placeholder="Enter Your Username">
                                    <i class="theme-cl ti-user"></i>
                                </div>
                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback error-msg" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            
                            <div class="form-group">
                                <label>Email</label>
                                <div class="input-with-icon">
                                    <input type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" 
                                    value="<?php echo e(old('email')); ?>" autocomplete="email" placeholder="Enter Your Email">
                                    <i class="theme-cl ti-email"></i>
                                </div>
                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback error-msg" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            
                            <div class="form-group">
                                <label>Password</label>
                                <div class="input-with-icon">
                                    <input type="password" name="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                     value="<?php echo e(old('password')); ?>" autocomplete="new-password" placeholder="Enter Your Password">
                                    <i class="theme-cl ti-lock"></i>
                                </div>
                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback error-msg" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            
                            <div class="form-group">
                                <label>Confirm Password</label>
                                <div class="input-with-icon">
                                    <input type="password" name="password_confirmation"  class="form-control <?php if ($errors->has('password_confirmation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password_confirmation'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Enter Confirm Password">
                                    <i class="theme-cl ti-lock"></i>
                                </div>
                                <?php if ($errors->has('password_confirmation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password_confirmation'); ?>
                                    <span class="invalid-feedback error-msg" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>

                            <div class="register-account text-center">
                                By hitting the <span class="theme-cl">"Register"</span> button, you agree to the <a class="theme-cl" href="#">Terms conditions</a> and <a class="theme-cl" href="#">Privacy Policy</a>
                            </div>
                            
                            <div class="form-groups">
                                <button type="submit" class="btn btn-primary theme-bg full-width">Register</button>
                            </div>
                        </form> -->
                        <!--
                        <div class="social-devider">
                            <span class="line"></span>
                            <span class="circle">Or</span>
                        </div>
                        
                        <div class="social-login row">
                            
                            <div class="col-md-6">
                                <a href="#" class="jb-btn-icon social-login-facebook"><i class="fa fa-facebook"></i>Facebook</a>
                            </div>
                            
                            <div class="col-md-6">
                                <a href="#" class="jb-btn-icon social-login-google"><i class="fa fa-google-plus"></i>Google</a>
                            </div>
                            
                            <div class="col-md-6">
                                <a href="#" class="jb-btn-icon social-login-twitter"><i class="fa fa-twitter"></i>Twitter</a>
                            </div>
                            
                            <div class="col-md-6">
                                <a href="#" class="jb-btn-icon social-login-linkedin"><i class="fa fa-linkedin"></i>Linkedin</a>
                            </div>
                            
                        </div>
                        -->
                    </div>
                    
                    <div id="employer" class="tab-pane fade">
                        <div class="form-group">
                            <label>User Name</label>
                            <div class="input-with-icon">
                                <input type="text" class="form-control" placeholder="Enter Your Username">
                                <i class="theme-cl ti-user"></i>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Company Name</label>
                            <div class="input-with-icon">
                                <input type="text" class="form-control" placeholder="Enter Your Username">
                                <i class="theme-cl ti-home"></i>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Email</label>
                            <div class="input-with-icon">
                                <input type="email" class="form-control" placeholder="Enter Your Email">
                                <i class="theme-cl ti-email"></i>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Password</label>
                            <div class="input-with-icon">
                                <input type="password" class="form-control" placeholder="Enter Your Password">
                                <i class="theme-cl ti-lock"></i>
                            </div>
                        </div>
                        
                        <div class="register-account text-center">
                            By hitting the <span class="theme-cl">"Register"</span> button, you agree to the <a class="theme-cl" href="#">Terms conditions</a> and <a class="theme-cl" href="#">Privacy Policy</a>
                        </div>
                        
                        <div class="form-groups">
                            <button type="submit" class="btn btn-primary theme-bg full-width">Register</button>
                        </div>
                        <!--
                        <div class="social-devider">
                            <span class="line"></span>
                            <span class="circle">Or</span>
                        </div>
                        
                        <div class="social-login row">
                            
                            <div class="col-md-6">
                                <a href="#" class="jb-btn-icon social-login-facebook"><i class="fa fa-facebook"></i>Facebook</a>
                            </div>
                            
                            <div class="col-md-6">
                                <a href="#" class="jb-btn-icon social-login-google"><i class="fa fa-google-plus"></i>Google</a>
                            </div>
                            
                            <div class="col-md-6">
                                <a href="#" class="jb-btn-icon social-login-twitter"><i class="fa fa-twitter"></i>Twitter</a>
                            </div>
                            
                            <div class="col-md-6">
                                <a href="#" class="jb-btn-icon social-login-linkedin"><i class="fa fa-linkedin"></i>Linkedin</a>
                            </div>
                            
                        </div>
                        -->
                    </div>
                    
                </div>
                    
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/onlinemariners/public_html/resources/views/userverificationer.blade.php ENDPATH**/ ?>