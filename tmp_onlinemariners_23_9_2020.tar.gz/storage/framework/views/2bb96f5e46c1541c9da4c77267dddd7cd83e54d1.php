<?php $__env->startSection('content'); ?>
<?php
	// echo "<pre>";
	// print_r($joblist);
	// // print_r($empImg[0]->pic_path);
	// exit;
?>
<!-- post a job -->
<style type="text/css">
	.table-bordered {
    	border: 1px solid #ddd;
	}
	input[type=search] {
		 border: 1px solid #ccc !important;
		 box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
	}
	.table>thead>tr>th {
	    border: 1px solid #ddd;
	}

</style>
<section class="dashboard-wrap">
				<div class="container-fluid">
					<div class="row">
					
						<!-- Sidebar Wrap -->
						<div class="col-lg-3 col-md-4">
							<div class="side-dashboard">
								<div class="dashboard-avatar">
									<?php 
	                                    $filename = $empImg[0]->pic_path;
	                                    //$url = url('/public/empProfile/'.$filename); 
	                                    if($filename == 'emp-default.png' || $filename == ''){
                                        $url = url('/public/assets/img/emp-default.png');     
	                                    }else{
	                                        $url = url('/public/empProfile/'.$filename); 
	                                    }
                                	?>
									<div class="dashboard-avatar-thumb">
									<?php if(isset($empImg)): ?>
                                    <img src="<?php echo e($url); ?>" class="img-avater" alt="emp-pic" />
                                	<?php else: ?>
                                    <img src="public/empProfile/emp-default.png" class="img-avater" alt="employer-profile-image" />
                                	<?php endif; ?>
									</div>
									
									<div class="dashboard-avatar-text">
										<h4><?php echo e(Session::get('employerName')); ?></h4>
									</div>
									
								</div>
								
								<div class="dashboard-menu">
									<!-- include from includes layouts-->
									<ul>
			                            <li class="<?php echo(request()->is('employer/dashboard')) ? 'active':'' ?>">
			                                <a href="<?php echo e(route('employer.dashboard')); ?>"><i class="ti-dashboard"></i>Dashboard</a>
			                            </li>
			                            <li class="<?php echo(request()->is('employer/profile')) ? 'active':'' ?>">
			                                <a href="<?php echo e(route('employer.profile')); ?>"><i class="ti-briefcase"></i>Create or Update Profile</a>
			                            </li>
			                            <!-- <li class="<?php //echo(request()->is('employer/edit')) ? 'active':'' ?>">
			                                <a href=""><i class="ti-briefcase"></i>Update Profile</a>
			                            </li> -->
			                            <?php if(isset($empImg[0]->profile_status) && ($empImg[0]->profile_status == 1)): ?>
			                            <li class="<?php echo(request()->is('employer/postajob')) ? 'active':'' ?>">
			                                <a href="<?php echo e(route('postjob.index')); ?>"><i class="ti-ruler-pencil"></i>Post New Job</a>
			                            </li>
			                            <li class="<?php echo(request()->is('employer/postajob/listing')) ? 'active':'' ?>">
			                                <a href="<?php echo e(route('postjob.listing')); ?>"><i class="ti-user"></i>Post Job Listing And Update</a>
			                            </li>    
			                            <li class="<?php echo(request()->is('employer/application/listing')) ? 'active':'' ?>">
			                                <a href="<?php echo e(route('lists.appliedjob')); ?>"><i class="ti-user"></i>Candidate Job Applied List</a>
			                            </li>
			                            <?php endif; ?>
			                            <!--
			                            <li><a href=""><i class="ti-user"></i>Applications</a></li>
			                            <li><a href=""><i class="ti-wallet"></i>Packages</a></li>
			                            <li><a href=""><i class="ti-cup"></i>Choose Packages</a></li>
			                            <li><a href=""><i class="ti-flag-alt-2"></i>Viewed Resume</a></li>
			                            <li><a href=""><i class="ti-id-badge"></i>Edit Profile</a></li>
			                            <li><a href=""><i class="ti-power-off"></i>Logout</a></li>
			                            <!-- <li class="">   -->
			                        </ul>
								</div>
							</div>
						</div>
						
						<!-- Content Wrap -->
						<div class="col-lg-9 col-md-8">
							<div class="dashboard-body">
								<?php if( session('success') ): ?>
		                            <div class="msg alert alert-success alert-dismissable fade in">
		                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		                                <b>Success ! </b><?php echo e(session('success')); ?>

		                            </div>
		                        <?php endif; ?>
		                        <!-- Flash Msg on success-->
		                        <?php if( session('error') ): ?>
		                            <div class="msg alert alert-danger alert-dismissable fade in">
		                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		                                <b>Error ! </b><?php echo e(session('error')); ?>

		                            </div>
		                        <?php endif; ?>
		                        <?php if( count($errors) > 0 ): ?>
		                            <div class="msg alert alert-danger alert-dismissable fade in">
		                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		                                <ul>
		                                     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                                         <li style="text-transform: capitalize;"><?php echo e($error); ?></li>
		                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                                </ul>
		                            </div>
		                        <?php endif; ?>
								<div class="dashboard-caption">
									
									<div class="dashboard-caption-header">
										<h4><i class="ti-ruler-pencil"></i>Post Job Listing And Update</h4>
									</div>
									
									<div class="dashboard-caption-wrap">
										<!-- table table-striped table-bordered -->
									<table id="postjob_listing" class="display table table-striped table-bordered dataTable" style="width:100%">
								        <thead>
								            <tr>
								                <th>Job Title</th>
								                <th>Company Name</th>								               
								                <th>Mobile No</th>
								                <th>Vassel Type</th>
								                <th>Application Deadline</th>
								                <th>Action</th>
								                <th>Details</th>
								            </tr>
								        </thead>
								        <tbody>
								        	<?php $__currentLoopData = $joblist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								            <tr>
								                <td><?php echo e(mb_strimwidth($job->job_title, 0, 20, "...")); ?></td>
								                <td><?php echo e(mb_strimwidth($job->company_name, 0, 20, "...")); ?></td>
								                <td><?php echo e(mb_strimwidth($job->mobile_number, 0, 20, "...")); ?></td>
								                <td><?php echo e(mb_strimwidth($job->vassel_type, 0, 20, "...")); ?></td>
								                <td><?php echo e(date('m-d-Y', strtotime($job->app_deadline))); ?></td>
								                <td>
								                	<form class="form-horizontal" method="get" action="<?php echo e(action('PostjobController@deleteJobs',['id' => $job->id , 'employer_id' => $job->employer_id])); ?>">
                                                	<!-- , 'employer_id' => $job->employer_id] -->
	                                                <a href="<?php echo e(route('postjob.edit',$job->id)); ?>" style="margin-right: 10px;" class="btn btn-info btn-xs"><i class="fa fa-edit"></i></a>
	                                                <?php echo e(csrf_field()); ?>

	                                                <input type="hidden" name="_method" value="DELETE">
	                                                <button type="submit" onclick="return confirm('Are You Sure ?');" class="btn btn-danger btn-xs"><i class='fa fa-trash'></i></button>
	                                            </form>

								                </td>
								                <td>
								                	<div style="padding-top: 8%">
								                		<a href="<?php echo e(route('postjob.detailsview',$job->id)); ?>" class="btn btn-warning btn-xs"><i class="fa fa-eye"></i></a>
							                		</div>
								                </td>
								            </tr>
								            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							            </tbody>
							            <tfoot>
								            <tr>
								                <th>Job Title</th>
								                <th>Company Name</th>								               
								                <th>Mobile No</th>
								                <th>Vassel Type</th>
								                <th>Application Deadline</th>
								                <th>Action</th>
								                <th>Details</th>
								            </tr>
								        </tfoot>
						            </table>
								</div>
							</div>
						</div>
					
					</div>
				</div>
			</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('datepicker'); ?>
<script>
	$(document).ready(function () {
	    $('#postjob_listing').DataTable();
    });


    $(".rank").change(function() {
        var multipleValues = $(".rank").val() || "";
        var result = "<label>Wages for Rank Position*: </label>";
        if (multipleValues != "") {
            var aVal = multipleValues.toString().split(",");
            $.each(aVal, function(i, value) {

                // result += "<div>";
                // result += "<input type='text' name='opval" + (parseInt(i) + 1) + "' value='" + "'"+value.trim()+"'" + "'>";
                // value = value.replace(' ','-');
                // value = value.replace('/','-');
                // result += "<input type='text' name='optext" + (parseInt(i) + 1) + "' value='" + $("#rank").find("option[value=" + value + "]").text().trim() + "'>";
                // result +="<div class='col-lg-6 col-md-6 col-sm-12'>" //(parseInt(i) + 1)
                result += "<input type='number' class='form-control' name='"+'wage[]' + "' placeholder='"+ 'Wages for '+value + "'value='' Required>";
                result += "</div>";
            });


        }
        //Set Result
        $("#wages").html(result);

    });
   
    
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_afterLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/onlinemariners/public_html/resources/views/employer/postjobListing.blade.php ENDPATH**/ ?>