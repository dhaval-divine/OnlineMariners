
        <div class="clearfix"></div>
        <div class="banner trans" style="background-image:url(<?php echo e(asset('public/assets/img/slider-1.jpg')); ?>);"  data-overlay="6">
            <div class="container">
                <div class="banner-caption">
                    <div class="col-md-12 col-sm-12 banner-text">
                        <h1>7,000+ Browse Jobs</h1>
                        <div class="full-search-2 eclip-search italian-search hero-search-radius">
							<div class="hero-search-content">
								
								<div class="row">
								
									<div class="col-lg-4 col-md-4 col-sm-12 small-padd">
										<div class="form-group">
											<div class="input-with-icon">
												<input type="text" class="form-control b-r" placeholder="Job Title or Keywords">
												<i class="ti-search"></i>
											</div>
										</div>
									</div>
									
									<div class="col-lg-3 col-md-3 col-sm-12 small-padd b-r">
										<div class="form-group">
										<div class="input-with-icon">
											<select id="choose-city" class="form-control">
												<option>Choose City</option>
												<option>Chandigarh</option>
												<option>London</option>
												<option>England</option>
												<option>Pratapcity</option>
												<option>Ukrain</option>
												<option>Wilangana</option>
											</select>
											<i class="ti-location-pin"></i>
										</div>
									</div>
									</div>
		
									
									<div class="col-lg-3 col-md-3 col-sm-12 small-padd">
										<div class="form-group">
										<div class="input-with-icon">
											<select id="choose-category" class="form-control">
												<option>Job Category</option>
												<option>Education & Trainee</option>
												<option>Sales & Marketing</option>
												<option>Automotive Jobs</option>
												<option>Health & Medical</option>
												<option>Design & Development</option>
												<option>Book Services</option>
											</select>
											<i class="ti-layers"></i>
										</div>
									</div>
									</div>
									
									<div class="col-lg-2 col-md-2 col-sm-12 small-padd">
										<div class="form-group">
											<div class="form-group">
												<a href="#" class="btn btn-primary search-btn">Search</a>
											</div>
										</div>
									</div>
									
								</div>
								
							</div>
						</div>
                    </div>
                </div>
            </div>
            
        </div>
        <div class="clearfix"></div>
        <!-- Company Brand Start -->
			<div class="company-brand">
				<div class="container">
					<div id="company-brands" class="owl-carousel">
						<div class="brand-img">
							<img src="<?php echo e(asset('public/assets/img/microsoft-home-dark.png')); ?>" class="img-responsive" alt="" />
						</div>
						<div class="brand-img">
							<img src="<?php echo e(asset('public/assets/img/img-home-dark.png')); ?>" class="img-responsive" alt="" />
						</div>
						<div class="brand-img">
							<img src="<?php echo e(asset('public/assets/img/mothercare-hom-darke.png')); ?>" class="img-responsive" alt="" />
						</div>
						<div class="brand-img">
							<img src="<?php echo e(asset('public/assets/img/paypal-home-dark.png')); ?>" class="img-responsive" alt="" />
						</div>
						<div class="brand-img">
							<img src="<?php echo e(asset('public/assets/img/serv-home-dark.png')); ?>" class="img-responsive" alt="" />
						</div>
						<div class="brand-img">
							<img src="<?php echo e(asset('public/assets/img/xerox-home-dark.png')); ?>" class="img-responsive" alt="" />
						</div>
						<div class="brand-img">
							<img src="<?php echo e(asset('public/assets/img/yahoo-home-dark.png')); ?>" class="img-responsive" alt="" />
						</div>
						<div class="brand-img">
							<img src="<?php echo e(asset('public/assets/img/mothercare-hom-darke.png')); ?>" class="img-responsive" alt="" />
						</div>
					</div>
				</div>
			</div>
			<!-- Company Brand End --><?php /**PATH C:\xampp\htdocs\mariners\resources\views/includes/header.blade.php ENDPATH**/ ?>