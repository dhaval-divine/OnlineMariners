<div class="message-wrapper">
    <ul class="messages">
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="message clearfix">
                
                <?php 
                    $candiuser = Session::get('userEmail');
                    $candidate = DB::select("select id from candidates where email ='".$candiuser."'"); 
                    if($candidate[0]->id){
                        $candiID = $candidate[0]->id;//Auth::id();    
                    }else{
                        $candiID = null;
                    }
                ?>
                <div class="<?php echo e(($message->from == $candiID) ? 'sent' : 'received'); ?>">
                    <p><?php echo e($message->message); ?></p>
                    <p class="date"><?php echo e(date('d M y, h:i a', strtotime($message->created_at))); ?></p>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>

<div class="input-text">
    <input type="text" name="message" class="submit">
</div>
<script>
setTimeout(function(){
    $('ul .active').trigger('click');
    }, 
    20000);
</script><?php /**PATH /home/onlinemariners/public_html/resources/views/messages/indexChatFromCandidate.blade.php ENDPATH**/ ?>