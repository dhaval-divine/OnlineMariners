<?php 
    // echo '<pre>';
    // print_r($allPostJobLists);
    // exit;
	$url = "'".url('/public/assets/img/banner-10.jpg')."'";
?>
<?php $__env->startSection('content'); ?>
<style type="text/css">
	.contact-form .btn-primary:hover, .contact-form .btn-primary:focus{
		max-width: 250px;
	    padding: 15px 25px !important;
	    height: auto;
	    margin: 15px auto;
	    display: block;
	    border: none;	    
	}
</style>
<!-- Title Header Start -->
<section class="inner-header-title" style="background-image:url(<?php echo e($url); ?>);">
	<div class="container">
		<h1>Contact Page</h1>
	</div>
</section>
<div class="clearfix"></div>
<!-- Title Header End -->

<!-- Contact Page Section Start -->
<section class="contact-page">
	<div class="container">
	<h2>Drop A Mail</h2>
	
		<div class="col-md-4 col-sm-4">
			<div class="contact-box">
				<i class="fa fa-map-marker"></i>
				<p>#Street 2122, Near New Market<br>London Uk (122546)</p>
			</div>
		</div>
		
		<div class="col-md-4 col-sm-4">
			<div class="contact-box">
				<i class="fa fa-envelope"></i>
				<p>careerdesk12@gmail.com<br>support@careerdesk.com</p>
			</div>
		</div>
		
		<div class="col-md-4 col-sm-4">
			<div class="contact-box">
				<i class="fa fa-phone"></i>
				<p>UK: 01 123 456 7895<br>Ind: +91 123 546 8758</p>
			</div>
		</div>
		
	</div>
</section>
<!-- contact section End -->

<!-- contact form -->
<section class="contact-form">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				 <?php if( session('success') ): ?>
                    <div class="msg alert alert-success alert-dismissable fade in">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <b>Success ! </b><?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if( session('error') ): ?>
                    <div class="msg alert alert-danger alert-dismissable fade in">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <b>Error ! </b><?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <?php if( count($errors) > 0 ): ?>
                    <div class="msg alert alert-danger alert-dismissable fade in">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <ul>
                             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <li style="text-transform: capitalize;"><?php echo e($error); ?></li>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
			</div>
		</div>
		<h2>Drop A Mail</h2>
		<form name="contact_us" action="<?php echo e(route('inquirysave')); ?>" method="post">
			<?php echo csrf_field(); ?>
			<div class="col-md-6 col-sm-6">
				<input type="text" name="name" class="form-control" placeholder="Your Name" required>
			</div>
			
			<div class="col-md-6 col-sm-6">
				<input type="email" name="email" class="form-control" placeholder="Your Email" required>
			</div>
			
			<div class="col-md-6 col-sm-6">
				<input type="number" name="phone_number" class="form-control" placeholder="Phone Number" required>
			</div>
			
			<div class="col-md-6 col-sm-6">
				<input type="text" name="subject" class="form-control" placeholder="Subject" required> 
			</div>
			
			<div class="col-md-12 col-sm-12">
				<textarea class="form-control" name="message" placeholder="Message" required></textarea>
			</div>
			
			<div class="col-md-12 col-sm-12">
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
		</form>
	</div>
</section>
<!-- Contact form End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_afterLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/onlinemariners/public_html/resources/views/contactus.blade.php ENDPATH**/ ?>