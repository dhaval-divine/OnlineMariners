 
<?php $__env->startSection('content'); ?>
<style type="text/css">
    .nav-tabs-custom>.nav-tabs>li:first-of-type {
        margin-left: 0;
    }
    .nav-tabs-custom>.nav-tabs>li.active {
        border-top-color: green;
    }
    .nav-tabs-custom>.nav-tabs>li {
        border-top: 3px solid transparent;
        margin-bottom: -2px;
        margin-right: 5px;
    }
    .nav-tabs-custom>.nav-tabs>li {
        border-top: 3px solid transparent;
        margin-bottom: -2px;
        margin-right: 5px;
    }
    .nav-tabs>li.active>a, .nav-tabs>li.active>a:hover, .nav-tabs>li.active>a:focus {
        color: #555;
        cursor: default;
        background-color: #fff;
        border: 1px solid #ddd;
        border-bottom-color: transparent;
    }
    .mand{
        color:red;
        font-weight: bold;
        font-size: 1.2em;
    }
    #endorse_table_wrapper .dataTables_length,#endorse_table_wrapper .dataTables_filter, #endorse_table_wrapper .dataTables_info,
    #endorse_table_wrapper .paging_simple_numbers {
        display: none;
    }
    #endorse_table_wrapper thead .sorting_asc , #endorse_table_wrapper .sorting{

        background-image: url('') !important;
    }
    
</style>
<!-- General Detail Start -->
<section class="dashboard-wrap">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar Wrap -->
            <div class="col-lg-3 col-md-4">
                <div class="side-dashboard">
                    <div class="dashboard-avatar">                                            
                        <div class="dashboard-avatar-thumb">                                
                            <?php     
                                // echo '<pre>';
                                // print_r($endors);
                                // exit;
                                foreach ($endors as $endors) {
                                    
                                }
                                $name = $profileimg[0]->profile_path;
                                $candidate_id = $profileimg[0]->id;
                                if($name == 'avatar-default.png'){
                                    $url = url('public/assets/img/avatar-default.png'); 
                                }else{
                                    $url = url('/public/profile/'.$name);
                                }  
                            ?>
                            <?php if(isset($name)): ?>
                            <img src="<?php echo e($url); ?>" class="img-avater" alt="img-avater" />
                            <?php else: ?>
                            <img src="<?php echo e(url('public/assets/img/avatar-default.png')); ?>" class="img-avater" alt="img-avater1" />
                            <?php endif; ?>                                                           
                        </div>
                        <div class="dashboard-avatar-text">
                            <h4 style="text-transform: capitalize;"><?php echo e(Session::get('userName')); ?></h4>
                        </div>                                                        
                    </div>
                    
                    <div class="dashboard-menu">
                        <ul>
                            <li><a href="<?php echo e(route('cand.dashboard')); ?>"><i class="ti-dashboard"></i>Dashboard</a></li>
                            <?php if($profileimg[0]->candidate_status == 0): ?>
                            <li><a href="<?php echo e(route('cand.profile')); ?>"><i class="ti-ruler-pencil"></i>Create Profile</a></li>
                            <?php endif; ?>
                            <?php if($profileimg[0]->candidate_status == 1): ?>
                            <li><a href="<?php echo e(route('cand.edit')); ?>"><i class="ti-briefcase"></i>Update Profile</a></li>
                            <?php endif; ?>
                            <li><a href="<?php echo e(route('cand.applylist')); ?>"><i class="ti-briefcase"></i>Job Applications</a></li>
                            <li class="active">
                                <a href="<?php echo e(route('endorsment.docs')); ?>"><i class="ti-briefcase"></i>Endorsements</a>
                            </li>                            
                            <!-- <li><a href=""><i class="ti-user"></i>Applications</a></li>
                            <li><a href=""><i class="ti-wallet"></i>Packages</a></li>
                            <li><a href=""><i class="ti-cup"></i>Choose Packages</a></li>
                            <li><a href=""><i class="ti-flag-alt-2"></i>Viewed Resume</a></li>
                            <li><a href=""><i class="ti-id-badge"></i>Edit Profile</a></li>
                            <li><a href=""><i class="ti-power-off"></i>Logout</a></li> -->
                        </ul>
                        <!-- <h4>For Candidate</h4>
                        <ul>
                            <li><a href="candidate-dashboard.html"><i class="ti-dashboard"></i>Candidate Dashboard</a></li>
                            <li><a href="candidate-resume.html"><i class="ti-wallet"></i>My Resume</a></li>
                            <li><a href="applied-jobs.html"><i class="ti-hand-point-right"></i>Applied Jobs</a></li>
                            <li><a href="saved-jobs.html"><i class="ti-heart"></i>Saved Jobs</a></li>
                            <li><a href="alert-jobs.html"><i class="ti-bell"></i>Alert Jobs</a></li>
                        </ul> -->
                    </div>
                </div>
            </div>
            
            <!-- Content Wrap -->
            <div class="col-lg-9 col-md-8">
                <!-- Flash Msg on success-->
                <?php if( session('success') ): ?>
                    <div class="alert alert-success alert-dismissable fade in" style="margin: 1% 0;">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <b>Success ! </b><?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <!-- Flash Msg on success-->
                <?php if( session('error') ): ?>
                    <div class="alert alert-danger alert-dismissable fade in" style="margin: 1% 0;">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <b>Error ! </b><?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
               <div class="dashboard-body">
                    <div class="dashboard-caption">
                        
                        <div class="dashboard-caption-header">
                            <h4><i class="ti-briefcase"></i>Documents Expiry Date</h4>
                        </div>
                        
                        <div class="dashboard-caption-wrap">
                            <div style="padding-bottom: 3%;">
                                <!-- <b class='mand'>* Indidate Mandatory Fields</b> -->
                            </div>
                              
                            <!-- Custom Tabs -->
                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                <!--1 Endorsements -->        
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingOne">
                                        <h4 class="panel-title">
                                            <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                Endorsements
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                        <div class="panel-body">
                                            <form name="endorse_form" method='POST' action="<?php echo e(route('endorsment.save')); ?>">
                                                <?php echo csrf_field(); ?>
                                                 <input type="hidden" name="candidate_id" value="<?php echo e($candidate_id); ?>">
                                                 <!-- <input type="hidden" name="document_type" value="Endorsements"> -->
                                                <table id="endorse_table" class="display" style="width:100%">
                                                <thead>
                                                    <tr>
                                                        <th>Doc No</th>
                                                        <th>Doc Name</th>
                                                        <th>Expiry Date</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>1</td>
                                                        <td>
                                                            DCE - Chemical(Dangerous Cargo Endorsement)
                                                            <input type="hidden" name="endors_name_dec_chemical" value="DCE - Chemical">
                                                        </td>
                                                        <td>
                                                            <input type="text" name="endors_dec_chemical_dt" id="endors_dec_chemical_dt" class="form-control" placeholder="Enter Expiry Date" value="<?php echo e(isset($endors->endors_dec_chemical_dt) ? date('m/d/Y', strtotime($endors->endors_dec_chemical_dt)) : ''); ?>">
                                                            <!-- <input type="text" name="endors_dec_chemical_dt" id="endors_dec_chemical"  data-lang="en" data-large-mode="true" data-dd-default-date="" data-min-year="1950" data-max-year="2220" data-disabled-days="08/17/2017,08/18/2017" data-id="datedropper-0" data-theme="my-style" class="form-control" placeholder="Enter Expiry Date" value="<?php echo e(isset($endors->endors_dec_chemical_dt) ? $endors->endors_dec_chemical_dt : ''); ?>" /> -->
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>
                                                            DCE - Gas(Dangerous Cargo Endorsement)
                                                            <input type="hidden" name="endors_name_dec_gas" value="DCE - Gas">
                                                        </td>
                                                        <td>
                                                            <input type="text" name="endors_dec_gas_dt" id="endors_dec_gas_dt" class="form-control" placeholder="Enter Expiry Date" value="<?php echo e(isset($endors->endors_dec_gas_dt) ? date('m/d/Y', strtotime($endors->endors_dec_gas_dt)) : ''); ?>" >
                                                            <!-- <input type="text" name="endors_dec_gas_dt" id="endors_dec_gas" data-lang="en" data-large-mode="true" data-min-year="1950" data-max-year="2220" data-disabled-days="08/17/2017,08/18/2017" data-id="datedropper-0" data-theme="my-style" class="form-control" value=""/> -->
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>3</td>
                                                        <td>
                                                            DCE - Others(Dangerous Cargo Endorsement)
                                                            <input type="hidden" name="endors_name_dec_others" value="DCE - Others">
                                                        </td>
                                                        <td>
                                                            <input type="text" name="endors_dec_others_dt" id="endors_dec_others_dt" class="form-control" placeholder="Enter Expiry Date" value="<?php echo e(isset($endors->endors_dec_others_dt) ? date('m/d/Y', strtotime($endors->endors_dec_others_dt)) : ''); ?>" >                                                           
                                                            <!-- <input type="text" name="endors_dec_others_dt" id="endors_dec_others" data-lang="en" data-large-mode="true" data-min-year="1950" data-max-year="2220" data-disabled-days="08/17/2017,08/18/2017" data-id="datedropper-0" data-theme="my-style" class="form-control" value=""/> -->
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>4</td>
                                                        <td>DCE - Petroleum (Dangerous Cargo Endorsement)
                                                            <input type="hidden" name="endors_name_dec_petroleum" value="DCE - Petroleum">
                                                        </td>
                                                        <td>
                                                            <input type="text" name="endors_dec_petroleum_dt" id="endors_dec_petroleum_dt" class="form-control" placeholder="Enter Expiry Date" value="<?php echo e(isset($endors->endors_dec_petroleum_dt) ? date('m/d/Y', strtotime($endors->endors_dec_petroleum_dt)) : ''); ?>">
                                                            <!-- <input type="text" name="endors_dec_petroleum_dt" id="endors_dec_petroleum" data-lang="en" data-large-mode="true" data-min-year="1950" data-max-year="2220" data-disabled-days="08/17/2017,08/18/2017" data-id="datedropper-0" data-theme="my-style" class="form-control" value=""/> -->
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>5</td>
                                                        <td>
                                                            Others<!-- <b class='mand'>*</b> -->
                                                            <input type="hidden" name="endors_name_others" value="Others">
                                                        </td>
                                                        <td>
                                                            <input type="text" name="endors_others_dt" id="endors_others_dt" class="form-control" placeholder="Enter Expiry Date" value="<?php echo e(isset($endors->endors_others_dt) ? date('m/d/Y', strtotime($endors->endors_others_dt)) : ''); ?>">
                                                            <!-- <input type="text" name="endors_others_dt" id="endors_others" data-lang="en" data-large-mode="true" data-min-year="1950" data-max-year="2220" data-disabled-days="08/17/2017,08/18/2017" data-id="datedropper-0" data-theme="my-style" class="form-control" placeholder="Enter Expiry Date" value=""/> -->
                                                        </td>
                                                    </tr>                                    
                                                </tbody>
                                            </table>
                                            <button type="submit" class="btn btn-success btn-primary small-btn">Save Docs</button>
                                           </form>
                                        </div>
                                    </div>
                                </div>

                                <!-- 2-->
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingTwo">
                                        <h4 class="panel-title">
                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                Travel Document
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                        <div class="panel-body">
                                            <form name="travel_docs_form" method='POST' action="<?php echo e(route('endorsment.save')); ?>">
                                                <?php echo csrf_field(); ?>
                                                 <input type="hidden" name="candidate_id" value="<?php echo e($candidate_id); ?>">
                                                 <!-- <input type="hidden" name="document_type" value="Endorsements"> -->
                                                <table id="endorse_table" class="display" style="width:100%">
                                                <thead>
                                                    <tr>
                                                        <th>Doc No</th>
                                                        <th>Doc Name</th>
                                                        <th>Expiry Date</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>1</td>
                                                        <td>
                                                            DCE - Chemical(Dangerous Cargo Endorsement)<b class='mand'>*</b>
                                                            <input type="hidden" name="endors_name_dec_chemical" value="DCE - Chemical">
                                                        </td>
                                                        <td>
                                                            <input type="text" name="endors_dec_chemical_dt" id="endors_dec_chemical_dt" class="form-control" placeholder="Enter Expiry Date" value="<?php echo e(isset($endors->endors_dec_chemical_dt) ? date('m/d/Y', strtotime($endors->endors_dec_chemical_dt)) : ''); ?>">
                                                            <!-- <input type="text" name="endors_dec_chemical_dt" id="endors_dec_chemical"  data-lang="en" data-large-mode="true" data-dd-default-date="" data-min-year="1950" data-max-year="2220" data-disabled-days="08/17/2017,08/18/2017" data-id="datedropper-0" data-theme="my-style" class="form-control" placeholder="Enter Expiry Date" value="<?php echo e(isset($endors->endors_dec_chemical_dt) ? $endors->endors_dec_chemical_dt : ''); ?>" /> -->
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>
                                                            DCE - Gas(Dangerous Cargo Endorsement)<b class='mand'>*</b>
                                                            <input type="hidden" name="endors_name_dec_gas" value="DCE - Gas">
                                                        </td>
                                                        <td>
                                                            <input type="text" name="endors_dec_gas_dt" id="endors_dec_gas_dt" class="form-control" placeholder="Enter Expiry Date" value="<?php echo e(isset($endors->endors_dec_gas_dt) ? date('m/d/Y', strtotime($endors->endors_dec_gas_dt)) : ''); ?>" >
                                                            <!-- <input type="text" name="endors_dec_gas_dt" id="endors_dec_gas" data-lang="en" data-large-mode="true" data-min-year="1950" data-max-year="2220" data-disabled-days="08/17/2017,08/18/2017" data-id="datedropper-0" data-theme="my-style" class="form-control" value=""/> -->
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>3</td>
                                                        <td>
                                                            DCE - Others(Dangerous Cargo Endorsement)<b class='mand'>*</b>
                                                            <input type="hidden" name="endors_name_dec_others" value="DCE - Others">
                                                        </td>
                                                        <td>
                                                            <input type="text" name="endors_dec_others_dt" id="endors_dec_others_dt" class="form-control" placeholder="Enter Expiry Date" value="<?php echo e(isset($endors->endors_dec_others_dt) ? date('m/d/Y', strtotime($endors->endors_dec_others_dt)) : ''); ?>" >                                                           
                                                            <!-- <input type="text" name="endors_dec_others_dt" id="endors_dec_others" data-lang="en" data-large-mode="true" data-min-year="1950" data-max-year="2220" data-disabled-days="08/17/2017,08/18/2017" data-id="datedropper-0" data-theme="my-style" class="form-control" value=""/> -->
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>4</td>
                                                        <td>DCE - Petroleum (Dangerous Cargo Endorsement)<b class='mand'>*</b>
                                                            <input type="hidden" name="endors_name_dec_petroleum" value="DCE - Petroleum">
                                                        </td>
                                                        <td>
                                                            <input type="text" name="endors_dec_petroleum_dt" id="endors_dec_petroleum_dt" class="form-control" placeholder="Enter Expiry Date" value="<?php echo e(isset($endors->endors_dec_petroleum_dt) ? date('m/d/Y', strtotime($endors->endors_dec_petroleum_dt)) : ''); ?>">
                                                            <!-- <input type="text" name="endors_dec_petroleum_dt" id="endors_dec_petroleum" data-lang="en" data-large-mode="true" data-min-year="1950" data-max-year="2220" data-disabled-days="08/17/2017,08/18/2017" data-id="datedropper-0" data-theme="my-style" class="form-control" value=""/> -->
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>5</td>
                                                        <td>
                                                            Others<b class='mand'>*</b>
                                                            <input type="hidden" name="endors_name_others" value="Others">
                                                        </td>
                                                        <td>
                                                            <input type="text" name="endors_others_dt" id="endors_others_dt" class="form-control" placeholder="Enter Expiry Date" value="<?php echo e(isset($endors->endors_others_dt) ? date('m/d/Y', strtotime($endors->endors_others_dt)) : ''); ?>">
                                                            <!-- <input type="text" name="endors_others_dt" id="endors_others" data-lang="en" data-large-mode="true" data-min-year="1950" data-max-year="2220" data-disabled-days="08/17/2017,08/18/2017" data-id="datedropper-0" data-theme="my-style" class="form-control" placeholder="Enter Expiry Date" value=""/> -->
                                                        </td>
                                                    </tr>                                    
                                                </tbody>
                                            </table>
                                            <button type="submit" class="btn btn-success btn-primary small-btn">Save Docs</button>
                                           </form>
                                        </div>
                                    </div>
                                </div>

                                <!-- 3 -->
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingThree">
                                        <h4 class="panel-title">
                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                Medical Document
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                        <div class="panel-body">
                                            Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                                        </div>
                                    </div>
                                </div>

                                
                                <!-- 4 -->
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingFour">
                                        <h4 class="panel-title">
                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                                
                                                Skills And Training Certificates
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
                                        <div class="panel-body">
                                            Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                                        </div>
                                    </div>
                                </div>

                                <!-- 5-->
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingFive">
                                        <h4 class="panel-title">
                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                                
                                                Personal Document
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseFive" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFive">
                                        <div class="panel-body">
                                            Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                                        </div>
                                    </div>
                                </div>

                                <!--6 -->
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingSix">
                                        <h4 class="panel-title">
                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                                COC
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseSix" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingSix">
                                        <div class="panel-body">
                                            Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                                        </div>
                                    </div>
                                </div>

                                <!--7 -->
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingSeven">
                                        <h4 class="panel-title">
                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                                                
                                                STCW
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseSeven" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingSeven">
                                        <div class="panel-body">
                                            Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                                        </div>
                                    </div>
                                </div>

                                <!--8 -->
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingEight">
                                        <h4 class="panel-title">
                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                                                
                                                Offshore Certification
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseEight" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingEight">
                                        <div class="panel-body">
                                            Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                                        </div>
                                    </div>
                                </div>

                                <!-- 9 -->
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingNine">
                                        <h4 class="panel-title">
                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
                                                
                                                Yacht Certification
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseNine" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingNine">
                                        <div class="panel-body">
                                            Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                                        </div>
                                    </div>
                                </div>

                                <!--10 -->
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingTen">
                                        <h4 class="panel-title">
                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                                                
                                                others
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseTen" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTen">
                                        <div class="panel-body">
                                            Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Accordion end  -->
                        </div>
                    </div>    
                </div>
            </div>
        
        </div>
    </div>
</section>
			<!-- General Detail End -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('datepicker'); ?>
<script>
    
    $(document).ready(function () {
            
        $('#endorse_table').DataTable();

        $( "#endors_dec_chemical_dt" ).datepicker({
            defaultDate: null,
            changeYear: true,
            changeMonth: true,
            yearRange: '1950:2100',
        });

        $('#endors_dec_gas_dt').datepicker({
            defaultDate: null,
            changeYear: true,
            changeMonth: true,
            yearRange: '1950:2100',
        });
        $('#endors_dec_others_dt').datepicker({
           defaultDate: null,
           changeYear: true,
           changeMonth: true,
            yearRange: '1950:2100',
        });
        $('#endors_dec_petroleum_dt').datepicker({
           defaultDate: null,
           changeYear: true,
           changeMonth: true,
            yearRange: '1950:2100',
        });
        $('#endors_others_dt').datepicker({
           defaultDate: null,
           changeYear: true,
           changeMonth: true,
            yearRange: '1950:2100',
        });
      
    });   
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_afterLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mariners\resources\views/candidate/endorsementDocuments.blade.php ENDPATH**/ ?>