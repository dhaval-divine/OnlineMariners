<?php $__env->startSection('content'); ?>
<?php
// echo '<pre>';
// print_r($ranklists);
// exit;

?>
<!-- Title Header Start -->
<section class="inner-header-title" style="background-image:url(<?php echo e(url('public/assets/img/banner-10.jpg')); ?>">
	<div class="container">
		<h1 style="text-transform: capitalize;">Select rank You want to apply</h1>
	</div>
</section>
<div class="clearfix"></div>
<!-- Title Header End -->
			
<!-- Candidate Detail Start -->
<section class="detail-desc">
	<div class="container">
	
		<div class="ur-detail-wrap top-lay">
			
			<div class="ur-detail-box">
				
				<div class="ur-thumb">

					<?php 
                        $filename = $emp[0]->company_logo;
                        $url = url('/public/companyLogo/'.$filename); 
                	?>
					<img src="<?php echo e($url); ?>" class="img-responsive" alt="company_logo" width="150" height="150" />
				</div>
				<div class="ur-caption">
					<h4 class="ur-title" style="text-transform: capitalize;"><?php echo e($emp[0]->company_name); ?></h4>
					<p class="ur-location"><i class="ti-location-pin mrg-r-5"></i><?php echo e($emp[0]->address); ?></p>
					<span class="ur-designation"><i class="ti-home mrg-r-5"></i><?php echo e($emp[0]->email); ?></span>

				</div>
				
			</div>
			
		</div>
		
	</div>
</section>

<!-- Job full detail Start -->
<section class="full-detail-description full-detail">
	<div class="container">
		<!-- Job Description -->
		<div class="col-md-12 col-sm-12">
			
			<div class="full-card90909">
				
				<div class="row" style="padding: 0% 0 6% 0">
					<div class="col-md-12  col-sm-12">
							<?php if( session('success') ): ?>
		                    <div class="alert alert-success alert-dismissable fade in">
		                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		                        <b>Success ! </b><?php echo e(session('success')); ?>

		                    </div>
			                <?php endif; ?>
			                <?php if( session('error') ): ?>
			                    <div class="alert alert-danger alert-dismissable fade in">
			                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			                        <b>Error ! </b><?php echo e(session('error')); ?>

			                    </div>
			                <?php endif; ?>
			                <?php if( count($errors) > 0 ): ?>
			                    <div class="alert alert-danger alert-dismissable fade in">
			                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			                        <ul>
			                             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                                 <li style="text-transform: capitalize;"><?php echo e($error); ?></li>
			                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                        </ul>
			                    </div>
			                <?php endif; ?>
            			</div>
					<div class="col-lg-offset-2 col-lg-10">

						
						
						<form method="POST" action="<?php echo e(route('save.rank')); ?>">
	                        <?php echo csrf_field(); ?>
	                        <input type="hidden" name="postjob_id" id="postjob_id" value="<?php echo e($ranklists[0]->postjob_id); ?>">
	                        <input type="hidden" name="employer_id" id="employer_id" value="<?php echo e($ranklists[0]->employer_id); ?>">
	                        <input type="hidden" name="postwage_id" id="postwage_id" value="">
	                        <div class="row" style="padding: 4% 0 4% 0">
	                            <div class="col-lg-4 col-md-6 col-sm-12">
	                                <label style="padding: 6% 0 10% 0;font-size: 1.2em;">Choose Rank you want to apply for*</label>
	                            </div>
	                           
	                            <div class="">
	                                <div class="col-lg-5 col-md-6 col-sm-12">
	                                    <select name="rank_position" id="jb-type" class="rank_position">
	                                        <option value=''>Choose Rank you want to apply for</option>
	                                        <?php $__currentLoopData = $ranklists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										        <option value='<?php echo e($rank->rank_position); ?>'><?php echo e($rank->rank_position); ?></option>
										    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
	                                    </select>
	                                </div>                        
	                            </div>
	                        </div>

							<div class="form-groups col-lg-offset-3" style="max-width: 25%; text-align: center; ">
                            	<button type="submit" class="btn btn-primary theme-bg full-width" style="font-weight: bold;">Apply For Job</button>
                        	</div>
						</div>  
					</div>
				</div>
				
				
			</div>
		</div>
		
	</div>
</section>
<!-- Job full detail End -->


<?php $__env->stopSection(); ?>
<?php $__env->startSection('datepicker'); ?>
<script>
	
   $('.rank_position').change(function(){
	  var rank = $('.rank_position').val();
	  var postjob_id = $('#postjob_id').val();
	  var employer_id = $('#employer_id').val();
	  console.log(rank+' ' + postjob_id +' ' +employer_id);
	  // return false;
	  $.ajaxSetup({
	    headers: {
	      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
	    }
	  });
	  $.ajax({
	    type:"POST",
	    url: "<?php echo e(route('job.data')); ?>",
	    data: { rank:rank, postjob_id:postjob_id, employer_id:employer_id},
	    success: function(data){
	    	var postwage_id = JSON.parse(data);
	    	$('#postwage_id').val(postwage_id);	      
	    }
	  })
	});
    
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_afterLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mariners\resources\views/candidate/choosePostforApply.blade.php ENDPATH**/ ?>