<?php $__env->startSection('content'); ?>
<?php
	// echo "<pre>";
	// print_r($joblist);	
	// exit;
?>
<!-- post a job -->
<section class="dashboard-wrap">
				<div class="container-fluid">
					<div class="row">
					
						<!-- Sidebar Wrap -->
						<div class="col-lg-3 col-md-4">
							<div class="side-dashboard">
								<div class="dashboard-avatar">
									<?php 
	                                    $filename = $empImg[0]->pic_path;
	                                    $url = url('/public/empProfile/'.$filename); 
                                	?>
									<div class="dashboard-avatar-thumb">
									<?php if(isset($empImg)): ?>
                                    <img src="<?php echo e($url); ?>" class="img-avater" alt="emp-pic" />
                                	<?php else: ?>
                                    <img src="public/empProfile/emp-default.png" class="img-avater" alt="employer-profile-image" />
                                	<?php endif; ?>
									</div>
									
									<div class="dashboard-avatar-text">
										<h4><?php echo e(Session::get('employerName')); ?></h4>
									</div>
									
								</div>
								
								<div class="dashboard-menu">
									<!-- include from includes layouts-->
									<?php echo $__env->make('includes.empNavLinks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								</div>
							</div>
						</div>
						
						<!-- Content Wrap -->
						<div class="col-lg-9 col-md-8">
							<div class="dashboard-body">
								<?php if( session('success') ): ?>
		                            <div class="alert alert-success alert-dismissable fade in">
		                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		                                <b>Success ! </b><?php echo e(session('success')); ?>

		                            </div>
		                        <?php endif; ?>
		                        <!-- Flash Msg on success-->
		                        <?php if( session('error') ): ?>
		                            <div class="alert alert-danger alert-dismissable fade in">
		                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		                                <b>Error ! </b><?php echo e(session('error')); ?>

		                            </div>
		                        <?php endif; ?>
		                        <?php if( count($errors) > 0 ): ?>
		                            <div class="alert alert-danger alert-dismissable fade in">
		                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		                                <ul>
		                                     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                                         <li style="text-transform: capitalize;"><?php echo e($error); ?></li>
		                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                                </ul>
		                            </div>
		                        <?php endif; ?>
								<div class="dashboard-caption">
									
									<div class="dashboard-caption-header">
										<h4><i class="ti-ruler-pencil"></i>Post New Page</h4>
									</div>
									
									<div class="dashboard-caption-wrap">
									<?php if($joblist): ?>
									<table id="postjob_listing" class="display" style="width:100%">
								        <thead>
								            <tr>
								                <th>Job Title</th>
								                <th>Candidate Name</th>
								                <th>Experience</th>
								                <th>Contact No</th>
								                <th>Rank Position</th>
								                <th>Available From</th>
								                <th>Status</th>
								                <th>Action</th>
								            </tr>
								        </thead>
								        <tbody>
								        	<?php $__currentLoopData = $joblist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								            <tr>
								                <td><?php echo e($job->job_title); ?></td>
								                <td style="text-transform: capitalize;"><?php echo e($job->candidate_name); ?></td>	        
								                <td><?php echo e($job->experience_years.' Years '.$job->experience_months.' Months'); ?></td>							              
								                <td><?php echo e($job->phone_number); ?></td>
								                <td><?php echo e($job->rank_position); ?></td>
								                <td><?php echo e(date('m-d-Y', strtotime($job->availablefrom))); ?></td>
								                <td>
								                								                		
						                			<label id="<?php echo 'current_status_'.$job->id ?>" >		
						                			</label>
							                		<div class="<?php echo e('old_status_'.$job->id); ?>">						                			
									                	<?php if($job->apply_status == 0): ?>
									                	<label class="label label-default">Pending</label>
									                	<?php elseif($job->apply_status == 1): ?>
									                	<label class="label label-success">Selected</label>
									                	<?php elseif($job->apply_status == 2): ?>
									                	<label class="label label-info">Shortlisted</label>
									                	<?php elseif($job->apply_status == 3): ?>
									                	<label class="label label-warning">Call For Interview</label>
									                	<?php elseif($job->apply_status == 4): ?>
									                	<label class="label label-primary">Under Review</label>
									                	<?php elseif($job->apply_status == 5): ?>
									                	<label class="label label-danger">Rejected</label>
									                	<?php endif; ?>
								                	</div>

								                </td>
								                <td>
								                	<form class="form-horizontal" method="post" action="">
								                		<?php echo e(csrf_field()); ?>

								                		<input type="hidden" name="job_apply_id" id="job_apply_id" class="job_apply_id" value="<?php echo e($job->id); ?>" class="">
								                		<select name="apply_status" data-id="<?php echo $job->id ?>" id="<?php echo $job->id ?>" class="apply_status">
														  <option value="">Select your action</option>
														  <option value="1">Selected</option>
														  <option value="2">Shortlist</option>
														  <option value="3">Called For Interview</option>
														  <option value="4">Under Review</option>
														  <option value="5">Reject</option>
														</select>                                      
	                                                <!-- <input type="hidden" name="_method" value="DELETE">
	                                                <button type="submit" onclick="return confirm('Are You Sure ?');" class="btn btn-danger btn-xs"><i class='fa fa-trash'></i></button> -->
	                                            </form>

								                </td>
								            </tr>
								            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							            </tbody>
							            <tfoot>
								            <tr>
								                <th>Job Title</th>
								                <th>Candidate Name</th>
								                <th>Experience</th>
								                <th>Contact No</th>
								                <th>Rank Position</th>
								                <th>Available From</th>
								                <th>Status</th>
								                <th>Action</th>
								            </tr>
								        </tfoot>
						            </table>
						            <?php endif; ?>
								</div>
							</div>
						</div>
					
					</div>
				</div>
			</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('datepicker'); ?>
<script>
	$(document).ready(function () {
	    $('#postjob_listing').DataTable();
	    // $('#current_status').hide();

	    $('.apply_status').change(function() {
	    	// var id = 	    	    	
	    	// var job_apply_id = $('.apply_status').attr('id');
	    	var apply_status = $(this).val();
	    	var job_apply_id = $(this).data('id');

	    	
	    	// alert('job_apply_id : '+ job_apply_id+ ' '+ apply_status);
	    	// return false;
	        $.ajaxSetup({
			    headers: {
			      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			    }
			});

	        $.ajax({
	            type: "POST",
	            dataType: "json",
	            url: "<?php echo e(route('change.applicationStatus')); ?>",
	            data: {'apply_status': apply_status, 'job_apply_id': job_apply_id},
	            success: function(data){
	    

            		$(".old_status_"+job_apply_id).hide();            		
            		$("#current_status_"+job_apply_id).removeAttr("class");
            		
            		if(data == 1){
            			$("#current_status_"+job_apply_id).addClass("label label-success");
            			$("#current_status_"+job_apply_id).text("Selected");            			
            		}else if(data == 2){
            			$("#current_status_"+job_apply_id).addClass("label label-info");
            			$("#current_status_"+job_apply_id).text("Shotlisted");
            		}else if(data == 3){
            			$("#current_status_"+job_apply_id).addClass("label label-warning");
            			$("#current_status_"+job_apply_id).text("Call For Interview");
            		}else if(data == 4){
            			$("#current_status_"+job_apply_id).addClass("label label-primary");
            			$("#current_status_"+job_apply_id).text("Under review");
            		}else if(data == 5){
            			$("#current_status_"+job_apply_id).addClass("label label-danger");
            			$("#current_status_"+job_apply_id).text("Rejected");
            		}

	            }
	        });
	    });

    });    
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_afterLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\mariners\resources\views/employer/jobListApplyByCandidate.blade.php ENDPATH**/ ?>