<?php
	// echo '<pre>';
	// print_r($candidateList);
	// exit;
?>
<?php $__env->startSection('content'); ?>
<!-- Title Header Start -->
			<section class="inner-header-title" style="background-image:url(<?php echo e(url('/public/assets/img/bn2.jpg')); ?>);">
				<div class="container">
					<h1>Candidate List</h1>
				</div>
			</section>
			<div class="clearfix"></div>
			<!-- Title Header End -->
			
			<!-- Browse Resume List Start -->
			<section class="manage-company">
				<div class="container">
					
					
					<div class="row">
					
						<!-- Single Candidate -->
						<?php $__currentLoopData = $candidateList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-4 col-sm-6">
							<a href="<?php echo e(route('cand.details', $candidate->id.'?frompage=candidategridlist')); ?>" class="item-click">
								<article>
									<div class="brows-resume grid-style">
										<div class="cnd-thumb-action">
											<div class="item-fl-box">
												<div class="brows-resume-pic">
													<?php
														$url = url('/public/profile/'.$candidate->profile_path);						
													?>
													<?php if(isset($url)): ?>
													<img src="<?php echo e($url); ?>" class="img-responsive" alt="" />
													<?php else: ?>
													<img src="<?php echo e(url('/public/public/assets/img/can-4.png')); ?>" class="img-responsive" alt="" />
													<?php endif; ?>
												</div>
												<div class="brows-resume-name">
													<h4><?php echo e($candidate->name); ?></h4>
													<span class="brows-resume-designation"><?php echo e(isset($candidate->applied_for) ? $candidate->applied_for : 'Not Updated Yet'); ?></span>
												</div>
											</div>
										</div>
										<div class="cnd-location">
											<div class="brows-resume-location">
												<p><i class="ti-location-pin"></i> 
													<?php echo e(isset($candidate->nationality) ? $candidate->nationality : 'Not Available'); ?>

												</p>
											</div>
										</div>
										<div class="cnd-skill">
											<div class="br-resume">
												<?php 
													if(($candidate->experience_years > 0) && ($candidate->experience_months > 0)){
														$exp = $candidate->experience_years.' Years '.$candidate->experience_months.' months';
													}else if(($candidate->experience_years > 0) && ($candidate->experience_months <1)){
														$exp = $candidate->experience_years.' Years ';
													}else if(($candidate->experience_years <1) && ($candidate->experience_months > 0)){
														$exp = $candidate->experience_months.' Months ';
													}else{
														$exp = 'No Experience';
													}
													
												?>
												Experience:<span> <?php echo e($exp ? $exp : 'Not Avilable'); ?> </span>
											</div>
										</div>
									</div>
								</article>
							</a>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						

					</div>
					
					<!-- <div class="row">
						<ul class="pagination">
							<li><a href="#"><i class="ti-arrow-left"></i></a></li>
							<li class="active"><a href="#">1</a></li>
							<li><a href="#">2</a></li>
							<li><a href="#">3</a></li> 
							<li><a href="#">4</a></li> 
							<li><a href="#"><i class="fa fa-ellipsis-h"></i></a></li> 
							<li><a href="#"><i class="ti-arrow-right"></i></a></li> 
						</ul>
					</div> -->
					
				</div>
			</section>
			<!-- Browse Resume List End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_afterLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/onlinemariners/public_html/resources/views/employer/browseCandidateGridList.blade.php ENDPATH**/ ?>