<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row" style="margin: 8% 1% 0 1%;">
            <div class="col-md-4">
                <div class="user-wrapper">
                    <ul class="users">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="user" id="<?php echo e($user->id); ?>">
                                
                                <div class="media">
                                    <div class="media-left">
                                        <?php                                            
                                            if($user->profile_path == '' || ($user->profile_path == 'emp-default.png')){
                                                $url = url('/public/assets/img/emp-default.png');
                                            }else{
                                                $url = url('/public/profile/'.$user->profile_path);
                                            }                                            
                                        
                                        ?>
                                        <img src="<?php echo e($url); ?>" alt="chat-user-left" class="media-object">
                                        <div style="position: relative;bottom: 6px;left: 9px;">
                                           <?php if($user->login_status == 1): ?>
                                            <span class="activeStatus"></span>
                                           <?php else: ?>
                                            <span class="deactiveStatus"></span>
                                           <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="media-body">
                                        <p class="name" style="text-transform: capitalize;"><?php echo e($user->candidate_name); ?></p>
                                        <p class="email"><?php echo e($user->email); ?></p>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>

            <div class="col-md-8" id="messages">

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.message_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/onlinemariners/public_html/resources/views/chat.blade.php ENDPATH**/ ?>