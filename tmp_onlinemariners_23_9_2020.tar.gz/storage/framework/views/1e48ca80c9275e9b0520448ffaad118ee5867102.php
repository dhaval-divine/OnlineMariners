<?php $__env->startSection('content'); ?>
<?php
	// echo "<pre>";
	// print_r($joblist);
	// // print_r($empImg[0]->pic_path);
	// exit;
?>
<!-- post a job -->
<section class="dashboard-wrap">
				<div class="container-fluid">
					<div class="row">
					
						<!-- Sidebar Wrap -->
						<div class="col-lg-3 col-md-4">
							<div class="side-dashboard">
								<div class="dashboard-avatar">
									<?php 
	                                    $filename = $empImg[0]->pic_path;
	                                    $url = url('/public/empProfile/'.$filename); 
                                	?>
									<div class="dashboard-avatar-thumb">
									<?php if(isset($empImg)): ?>
                                    <img src="<?php echo e($url); ?>" class="img-avater" alt="emp-pic" />
                                	<?php else: ?>
                                    <img src="public/empProfile/emp-default.png" class="img-avater" alt="employer-profile-image" />
                                	<?php endif; ?>
									</div>
									
									<div class="dashboard-avatar-text">
										<h4><?php echo e(Session::get('employerName')); ?></h4>
									</div>
									
								</div>
								
								<div class="dashboard-menu">
									<!-- include from includes layouts-->
									<?php echo $__env->make('includes.empNavLinks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								</div>
							</div>
						</div>
						
						<!-- Content Wrap -->
						<div class="col-lg-9 col-md-8">
							<div class="dashboard-body">
								<?php if( session('success') ): ?>
		                            <div class="alert alert-success alert-dismissable fade in">
		                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		                                <b>Success ! </b><?php echo e(session('success')); ?>

		                            </div>
		                        <?php endif; ?>
		                        <!-- Flash Msg on success-->
		                        <?php if( session('error') ): ?>
		                            <div class="alert alert-danger alert-dismissable fade in">
		                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		                                <b>Error ! </b><?php echo e(session('error')); ?>

		                            </div>
		                        <?php endif; ?>
		                        <?php if( count($errors) > 0 ): ?>
		                            <div class="alert alert-danger alert-dismissable fade in">
		                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		                                <ul>
		                                     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                                         <li style="text-transform: capitalize;"><?php echo e($error); ?></li>
		                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                                </ul>
		                            </div>
		                        <?php endif; ?>
								<div class="dashboard-caption">
									
									<div class="dashboard-caption-header">
										<h4><i class="ti-ruler-pencil"></i>Post New Page</h4>
									</div>
									
									<div class="dashboard-caption-wrap">
									<table id="postjob_listing" class="display" style="width:100%">
								        <thead>
								            <tr>
								                <th>Job Title</th>
								                <th>Company Name</th>
								                <th>Contact Person</th>
								                <th>Mobile No</th>
								                <th>Vassel Type</th>
								                <th>Application Deadline</th>
								                <th>Action</th>
								            </tr>
								        </thead>
								        <tbody>
								        	<?php $__currentLoopData = $joblist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								            <tr>
								                <td><?php echo e($job->job_title); ?></td>
								                <td><?php echo e($job->company_name); ?></td>							        
								                <td><?php echo e($job->contact_person); ?></td>							              
								                <td><?php echo e($job->mobile_number); ?></td>
								                <td><?php echo e($job->vassel_type); ?></td>
								                <td><?php echo e(date('m-d-Y', strtotime($job->app_deadline))); ?></td>
								                <td>
								                	<form class="form-horizontal" method="get" action="<?php echo e(action('PostjobController@deleteJobs',['id' => $job->id , 'employer_id' => $job->employer_id])); ?>">
                                                	<!-- , 'employer_id' => $job->employer_id] -->
	                                                <a href="<?php echo e(route('postjob.edit',$job->id)); ?>" class="btn btn-info btn-xs"><i class="fa fa-edit"></i></a>
	                                                <?php echo e(csrf_field()); ?>

	                                                <input type="hidden" name="_method" value="DELETE">
	                                                <button type="submit" onclick="return confirm('Are You Sure ?');" class="btn btn-danger btn-xs"><i class='fa fa-trash'></i></button>
	                                            </form>

								                </td>
								            </tr>
								            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							            </tbody>
							            <tfoot>
								            <tr>
								                <th>Job Title</th>
								                <th>Company Name</th>
								                <th>Contact Person</th>
								                <th>Mobile No</th>
								                <th>Vassel Type</th>
								                <th>Application Deadline</th>
								                <th>Action</th>
								            </tr>
								        </tfoot>
						            </table>
								</div>
							</div>
						</div>
					
					</div>
				</div>
			</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('datepicker'); ?>
<script>
	$(document).ready(function () {
	    $('#postjob_listing').DataTable();
    });


    $(".rank").change(function() {
        var multipleValues = $(".rank").val() || "";
        var result = "<label>Wages for Rank Position*: </label>";
        if (multipleValues != "") {
            var aVal = multipleValues.toString().split(",");
            $.each(aVal, function(i, value) {

                // result += "<div>";
                // result += "<input type='text' name='opval" + (parseInt(i) + 1) + "' value='" + "'"+value.trim()+"'" + "'>";
                // value = value.replace(' ','-');
                // value = value.replace('/','-');
                // result += "<input type='text' name='optext" + (parseInt(i) + 1) + "' value='" + $("#rank").find("option[value=" + value + "]").text().trim() + "'>";
                // result +="<div class='col-lg-6 col-md-6 col-sm-12'>" //(parseInt(i) + 1)
                result += "<input type='number' class='form-control' name='"+'wage[]' + "' placeholder='"+ 'Wages for '+value + "'value='' Required>";
                result += "</div>";
            });


        }
        //Set Result
        $("#wages").html(result);

    });
   
    
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_afterLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\mariners\resources\views/employer/postjobListing.blade.php ENDPATH**/ ?>