 
<?php $__env->startSection('content'); ?>
<!-- General Detail Start -->
<section class="dashboard-wrap">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar Wrap -->
            <div class="col-lg-3 col-md-4">
                <div class="side-dashboard">
                    <div class="dashboard-avatar">
                        <form class="emp-img-form"  method="POST" action="<?php echo e(route('employer.image')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>      
                            <div class="dashboard-avatar-thumb">
                                <?php 
                                    $filename = $empImg[0]->pic_path;
                                    $url = url('/public/empProfile/'.$filename); 
                                ?>
                                <?php if(isset($empImg)): ?>
                                    <img src="<?php echo e($url); ?>" class="img-avater" alt="emp-pic" />
                                <?php else: ?>
                                    <img src="public/empProfile/emp-default.png" class="img-avater" alt="employer-profile-image" />
                                <?php endif; ?>
                                
                            </div>
                            <div class="dashboard-avatar-text">
                                <h4><?php echo e(Session::get('employerName')); ?></h4>
                            </div>
                            <div class="col-md-12 col-sm-12">
                                <div class="form-group">
                                    <span class="control-fileupload">
                                    <label for="file">Update Profile Image</label>
                                    <input type="file" name="pic_path" id="pic_path">
                                    </span>
                                </div>
                            </div>
                            <input type="submit" name="submit" value="Update"> 
                        </form>
                            
                    </div>
                    
                    <div class="dashboard-menu">
                        <!-- include from includes layouts-->
                        <?php echo $__env->make('includes.empNavLinks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
            
            <!-- Content Wrap -->
            <div class="col-lg-9 col-md-8">
                <div class="dashboard-body">
                        
                    <div class="dashboard-caption">
                        
                        <div class="dashboard-caption-header">
                            <h4><i class="ti-settings"></i>Dashboard</h4>
                        </div>
                        
                        <div class="dashboard-caption-wrap">
                        
                            <!-- Overview -->
                            <div class="row">
                                <div class="col-lg-3 col-md-6 col-sm-12">
                                    <div class="dashboard-stat widget-1">
                                        <div class="dashboard-stat-content"><h4>210</h4> <span>Job Posted</span></div>
                                        <div class="dashboard-stat-icon"><i class="ti-location-pin"></i></div>
                                    </div>	
                                </div>
                                
                                <div class="col-lg-3 col-md-6 col-sm-12">
                                    <div class="dashboard-stat widget-2">
                                        <div class="dashboard-stat-content"><h4>80</h4> <span>Pending Jobs</span></div>
                                        <div class="dashboard-stat-icon"><i class="ti-layers"></i></div>
                                    </div>	
                                </div>
                                
                                <div class="col-lg-3 col-md-6 col-sm-12">
                                    <div class="dashboard-stat widget-3">
                                        <div class="dashboard-stat-content"><h4>712</h4> <span>Total Views</span></div>
                                        <div class="dashboard-stat-icon"><i class="ti-pie-chart"></i></div>
                                    </div>	
                                </div>
                                
                                <div class="col-lg-3 col-md-6 col-sm-12">
                                    <div class="dashboard-stat widget-4">
                                        <div class="dashboard-stat-content"><h4>107</h4> <span>Expire Jobs</span></div>
                                        <div class="dashboard-stat-icon"><i class="ti-bookmark"></i></div>
                                    </div>	
                                </div>
                            </div>
                            
                            <!-- Notifications -->
                            <!-- <div class="row">
                                <div class="col-lg-6 col-md-12">
                                    <div class="dashboard-gravity-list with-icons">
                                        <h4>Recent Activities</h4>
                                        <ul>
                                            <li>
                                                <i class="dash-icon-box ti-layers"></i> Your job <strong><a href="#">App Developer</a></strong> has been approved!
                                                <a href="#" class="close-list-item"><i class="fa fa-close"></i></a>
                                            </li>

                                            <li>
                                                <i class="dash-icon-box ti-star"></i> Your job <strong><a href="#">Android Developer</a></strong> expire soon!
                                                <a href="#" class="close-list-item"><i class="fa fa-close"></i></a>
                                            </li>

                                            <li>
                                                <i class="dash-icon-box ti-heart"></i> Someone bookmarked your <strong><a href="#">Web Designer</a></strong> job!
                                                <a href="#" class="close-list-item"><i class="fa fa-close"></i></a>
                                            </li>

                                            <li>
                                                <i class="dash-icon-box ti-star"></i> Gracie Mahmood left a review <div class="numerical-rating mid" data-rating="3.8"></div> on <strong><a href="#">Sonal Cafe</a></strong>
                                                <a href="#" class="close-list-item"><i class="fa fa-close"></i></a>
                                            </li>

                                            <li>
                                                <i class="dash-icon-box ti-heart"></i> Your job <strong><a href="#">UI/UX Designer</a></strong> has been approved!
                                                <a href="#" class="close-list-item"><i class="fa fa-close"></i></a>
                                            </li>

                                            <li>
                                                <i class="dash-icon-box ti-heart"></i> Someone bookmarked your <strong><a href="#">PHP Developer</a></strong> job!
                                                <a href="#" class="close-list-item"><i class="fa fa-close"></i></a>
                                            </li>

                                            <li>
                                                <i class="dash-icon-box ti-star"></i> Your job <strong><a href="#">Software Developer</a></strong> expire soon!
                                                <a href="#" class="close-list-item"><i class="fa fa-close"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                
                                <div class="col-lg-6 col-md-12">
                                    <div class="dashboard-gravity-list invoices with-icons">
                                        <h4>Invoices</h4>
                                        <ul>
                                            
                                            <li><i class="dash-icon-box ti-files"></i>
                                                <strong>Starter Plan</strong>
                                                <ul>
                                                    <li class="unpaid">Unpaid</li>
                                                    <li>Order: #20551</li>
                                                    <li>Date: 01/08/2019</li>
                                                </ul>
                                                <div class="buttons-to-right">
                                                    <a href="#" class="button gray">View Invoice</a>
                                                </div>
                                            </li>
                                            
                                            <li><i class="dash-icon-box ti-files"></i>
                                                <strong>Basic Plan</strong>
                                                <ul>
                                                    <li class="paid">Paid</li>
                                                    <li>Order: #20550</li>
                                                    <li>Date: 01/07/2019</li>
                                                </ul>
                                                <div class="buttons-to-right">
                                                    <a href="#" class="button gray">View Invoice</a>
                                                </div>
                                            </li>

                                            <li><i class="dash-icon-box ti-files"></i>
                                                <strong>Extended Plan</strong>
                                                <ul>
                                                    <li class="paid">Paid</li>
                                                    <li>Order: #20549</li>
                                                    <li>Date: 01/06/2019</li>
                                                </ul>
                                                <div class="buttons-to-right">
                                                    <a href="#" class="button gray">View Invoice</a>
                                                </div>
                                            </li>
                                            
                                            <li><i class="dash-icon-box ti-files"></i>
                                                <strong>Platinum Plan</strong>
                                                <ul>
                                                    <li class="paid">Paid</li>
                                                    <li>Order: #20548</li>
                                                    <li>Date: 01/05/2019</li>
                                                </ul>
                                                <div class="buttons-to-right">
                                                    <a href="#" class="button gray">View Invoice</a>
                                                </div>
                                            </li>
                                            
                                            <li><i class="dash-icon-box ti-files"></i>
                                                <strong>Extended Plan</strong>
                                                <ul>
                                                    <li class="paid">Paid</li>
                                                    <li>Order: #20547</li>
                                                    <li>Date: 01/04/2019</li>
                                                </ul>
                                                <div class="buttons-to-right">
                                                    <a href="#" class="button gray">View Invoice</a>
                                                </div>
                                            </li>
                                            
                                            <li><i class="dash-icon-box ti-files"></i>
                                                <strong>Platinum Plan</strong>
                                                <ul>
                                                    <li class="paid">Paid</li>
                                                    <li>Order: #20546</li>
                                                    <li>Date: 01/03/2019</li>
                                                </ul>
                                                <div class="buttons-to-right">
                                                    <a href="#" class="button gray">View Invoice</a>
                                                </div>
                                            </li>

                                        </ul>
                                    </div>
                                </div>	
                            </div> -->
                            
                        </div>
                        
                    </div>
                </div>
            </div>
        
        </div>
    </div>
</section>
			<!-- General Detail End -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('datepicker'); ?>
<script>
    $('#candidate-dob').dateDropper();
    $('#availablefrom').dateDropper();
    $('#expirejob').dateDropper();
    
    //resume upload 
    $(function() {
      $('input[type=file]').change(function(){
        var t = $(this).val();
        var labelText = 'File : ' + t.substr(12, t.length);
        $(this).prev('label').text(labelText);
      })
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_afterLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/onlinemariners/public_html/resources/views/employer/employerdashboard.blade.php ENDPATH**/ ?>