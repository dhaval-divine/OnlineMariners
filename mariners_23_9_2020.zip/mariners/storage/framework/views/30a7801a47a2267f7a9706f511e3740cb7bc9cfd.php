<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <!-- Basic Page Needs==================================================-->
    <title>Online Mariners | Homepage</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- CSS==================================================-->
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/plugins/css/plugins.css')); ?>">
    <link href="<?php echo e(asset('public/assets/css/style.css')); ?>" rel="stylesheet">
    <link type="text/css" rel="stylesheet" id="jssDefault" href="<?php echo e(asset('public/assets/css/colors/green-style.css')); ?>"> 
    
    <!-- Js Jquery basic-->
    <script type="text/javascript" src="<?php echo e(asset('public/assets/plugins/js/jquery.min.js')); ?>"></script> 
</head>

<body>
    <div class="Loader"></div>
    <!--- Hearder -->
    <div class="wrapper">
        <!-- Menu Navigation list -->
        <?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- BG image Home page -->
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>


</body>
</html><?php /**PATH C:\xampp\htdocs\mariners\resources\views/layouts/app_website.blade.php ENDPATH**/ ?>