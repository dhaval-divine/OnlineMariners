<?php $__env->startComponent('mail::message'); ?>


Welcome <label style='text-transform: capitalize;'><?php echo e($data['username']); ?></label>,

Click on below button to varify Email Address
<?php $__env->startComponent('mail::button', ['url' => $data['url'] ]); ?>
Varify Email
<?php echo $__env->renderComponent(); ?>

Thanks&Regards,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/onlinemariners/public_html/resources/views/emails/emailvarification.blade.php ENDPATH**/ ?>