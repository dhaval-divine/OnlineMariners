<?php $__env->startSection('content'); ?>
<?php
// echo '<pre>';
// print_r($wagelisting);

?>
<!-- Title Header Start -->
<section class="inner-header-title" style="background-image:url(<?php echo e(url('public/assets/img/banner-10.jpg')); ?>">
	<div class="container">
		<h1>Job Detail</h1>
	</div>
</section>
<div class="clearfix"></div>
<!-- Title Header End -->
			
<!-- Candidate Detail Start -->
<section class="detail-desc">
	<div class="container">
	
		<div class="ur-detail-wrap top-lay">
			
			<div class="ur-detail-box">
				
				<div class="ur-thumb">

					<?php 
                        $filename = $emp[0]->company_logo;
                        $url = url('/public/companyLogo/'.$filename); 
                	?>
					<img src="<?php echo e($url); ?>" class="img-responsive" alt="company_logo" width="150" height="150" />
				</div>
				<div class="ur-caption">
					<h4 class="ur-title" style="text-transform: capitalize;"><?php echo e($emp[0]->company_name); ?></h4>
					<p class="ur-location"><i class="ti-location-pin mrg-r-5"></i><?php echo e($emp[0]->address); ?></p>
					<span class="ur-designation"><i class="ti-home mrg-r-5"></i><?php echo e($emp[0]->email); ?></span>

				</div>
				
			</div>
			
			<?php if(Session::get('userEmail')): ?>
			<div class="ur-detail-btn">				
				<a href="javascript:void(0)" data-toggle="modal" data-target="#apply-job" class="btn btn-warning mrg-bot-10 full-width"><i class="ti-star mrg-r-5"></i>Apply This Job</a><br>					
				<!-- <a href="#" class="btn btn-info full-width"><i class="ti-linkedin mrg-r-5"></i>Apply With Linkedin</a> -->
			</div>
			<?php endif; ?>
		</div>
		
	</div>
</section>

<?php
// echo "<pre>";
// print_r($wagelisting);
// print_r($wages);
// print_r($emp);
// exit;

?>
<!-- Job full detail Start -->
<section class="full-detail-description full-detail">
	<div class="container">
		<!-- Job Description -->
		<div class="col-md-12 col-sm-12">
			<div class="full-card">
			
				
				<div class="row row-bottom mrg-0">
					<h2 class="detail-title">Job Detail</h2>
					<ul class="job-detail-des">
						<li><span>Job Title:</span><?php echo e($postjobs[0]->job_title); ?></li>
						<li><span>Contact Person:</span><?php echo e($emp[0]->contact_person); ?></li>
						<li><span>Vassel Type:</span><?php echo e($wagelisting[0]->vassel_type); ?></li>
						<li><span>Lat Date To Apply:</span><?php echo e(date('m-d-Y', strtotime($postjobs[0]->app_deadline))); ?></li>
						<?php $__currentLoopData = $wagelisting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>						
						<li style="font-size: 1.3em;font-weight:bold;margin-top: 3%;"><span><?php echo e('Job for Rank '.$wage->rank_position); ?></span></li>
						<li><span>Contact Duration:</span><?php echo e($wage->contract_duration); ?></li>
						<li><span>Experince In Years:</span><?php echo e($wage->experience_years); ?></li>
						<li><span>Experince In Months:</span><?php echo e($wage->experience_months); ?></li>
						<li><span>Wage For The Post:</span><?php echo e('$ '.$wage->wages); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>						
					</ul>
				</div>
				<div class="row row-bottom mrg-0">
					<h2 class="detail-title">Job Description</h2>
					<ul class="job-detail-des">
						<li><?php echo e($postjobs[0]->job_description); ?></li>
					</ul>					
				</div>
				<div class="row row-bottom mrg-0">
					<h2 class="detail-title">Location</h2>
					<ul class="job-detail-des">
						<li><span>Address:</span><?php echo e($postjobs[0]->address); ?></li>
						<li><span>City: </span><?php echo e($postjobs[0]->city); ?></li>
						<li><span>State: </span><?php echo e($postjobs[0]->state); ?></li>
						<li><span>Country: </span><?php echo e($postjobs[0]->country); ?></li>
						<!-- <li><span>Zip:</span>520 548</li> -->
						<li><span>Telephone:</span><?php echo e($emp[0]->mobile_number); ?></li>
						<!-- <li><span>Fax:</span>(622) 123 456</li> -->
						<li><span>Email:</span><?php echo e($emp[0]->email); ?></li>
					</ul>
				</div>
				
				
				
				<!-- <div class="row row-bottom mrg-0">
				<h2 class="detail-title">Skill Requirement</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
				<ul class="detail-list">
					<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</li>
					<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.</li>
					<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.</li>
					<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.</li>
					<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.</li>
				</ul>
				</div> -->
				
				<!-- <div class="row row-bottom mrg-0">
					<h2 class="detail-title">Map Location</h2>
					<div id="map_full_width_one" class="full-width" style="height:400px;"></div>
				</div> -->
			</div>
		</div>
		<!-- End Job Description -->
		
		<!-- Start Sidebar -->
		<div class="col-md-4 col-sm-12">
			<!-- <div class="sidebar right-sidebar">
			
				<!-- Job Alert -->
				<!-- <a href="javascript:void(0)" class="btn btn-info full-width mrg-bot-20" data-toggle="modal" data-target="#job-alert">Get Job Alert!</a> -->
				
				
				<!-- <div class="side-widget">
					<h2 class="side-widget-title">Job Overview</h2>
					<div class="widget-text padd-0">
						<div class="ur-detail-wrap">
							<div class="ur-detail-wrap-body padd-top-20">
								<ul class="ove-detail-list">
								
									<li>
										<i class="ti-wallet"></i>
										<h5>Offerd Salary</h5>
										<span>£15,000 - £20,000</span>
									</li>
									
									<li>
										<i class="ti-user"></i>
										<h5>Gender</h5>
										<span>Male</span>
									</li>
									
									<li>
										<i class="ti-ink-pen"></i>
										<h5>Career Level</h5>
										<span>Excutive</span>
									</li>
									
									<li>
										<i class="ti-home"></i>
										<h5>Industry</h5>
										<span>Management</span>
									</li>
									
									<li>
										<i class="ti-shield"></i>
										<h5>Experience</h5>
										<span>5 Years</span>
									</li>
									
									<li>
										<i class="ti-book"></i>
										<h5>Qualification</h5>
										<span>Master Degree</span>
									</li>
									
								</ul>
							</div>
						</div>
					</div>
				</div>	 -->
				
				<!-- <div class="statistic-item flex-middle">
					<div class="icon text-theme">
						<i class="ti-time theme-cl"></i>
					</div>
					<span class="text"><span class="number">2 months</span> ago</span>
				</div>
				
				<div class="statistic-item flex-middle">
					<div class="icon text-theme">
						<i class="ti-zoom-in theme-cl"></i>
					</div>
					<span class="text"><span class="number">1742</span> Views</span>
				</div>
				
				<div class="statistic-item flex-middle">
					<div class="icon text-theme">
					  <i class="ti-write theme-cl"></i>
					</div>
					<span class="text"><span class="number">17</span> Applicants</span>
				</div>
				
				
				<div class="sidebar-widgets">
				
					<div class="ur-detail-wrap">
						<div class="ur-detail-wrap-header">
							<h4>Get In Touch</h4>
						</div>
						<div class="ur-detail-wrap-body">
							<form action="#">
								<div class="form-group">
									<label>Name</label>
									<input type="email" class="form-control">
								</div>
								<div class="form-group">
									<label>Email</label>
									<input type="email" class="form-control">
								</div>
								<div class="form-group">
									<label>Message</label>
									<textarea class="form-control"></textarea>
								</div>
								<button type="submit" class="btn btn-primary">Submit</button>
							</form>
						</div>
					</div>
					
				</div> -->
				<!-- /Say Hello -->
				
			</div> 
		</div>
		<!-- End Sidebar -->
	</div>
</section>
<!-- Job full detail End -->


<?php $__env->stopSection(); ?>
<?php $__env->startSection('datepicker'); ?>
<script>
	$(document).ready(function () {
	    $('#postjob_listing').DataTable();
    });


    $(".rank").change(function() {
        var multipleValues = $(".rank").val() || "";
        var result = "<label>Wages for Rank Position*: </label>";
        if (multipleValues != "") {
            var aVal = multipleValues.toString().split(",");
            $.each(aVal, function(i, value) {

                // result += "<div>";
                // result += "<input type='text' name='opval" + (parseInt(i) + 1) + "' value='" + "'"+value.trim()+"'" + "'>";
                // value = value.replace(' ','-');
                // value = value.replace('/','-');
                // result += "<input type='text' name='optext" + (parseInt(i) + 1) + "' value='" + $("#rank").find("option[value=" + value + "]").text().trim() + "'>";
                // result +="<div class='col-lg-6 col-md-6 col-sm-12'>" //(parseInt(i) + 1)
                result += "<input type='number' class='form-control' name='"+'wage[]' + "' placeholder='"+ 'Wages for '+value + "'value='' Required>";
                result += "</div>";
            });


        }
        //Set Result
        $("#wages").html(result);

    });
   
    
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_afterLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/onlinemariners/public_html/resources/views/employer/jobListingView.blade.php ENDPATH**/ ?>